import { Pressable, StyleSheet, Text } from 'react-native';
import type { Jugador } from '../engine/juego';
import { useTema } from '../temas';
import { Caja } from './Capa';

type Props = {
  jugador: number; // quien ha caído en el pozo
  resultado: 'atrapado' | 'condena' | 'rescate';
  liberado: number | null; // a quien rescata, si cae justo donde había alguien
  jugadores: Jugador[];
  onTerminar: () => void;
};

export function EscenaPozoAviso({ jugador, resultado, liberado, jugadores, onTerminar }: Props) {
  const tema = useTema();
  const nombre = jugadores[jugador].nombre;
  const otro = jugadores[(jugador + 1) % jugadores.length].nombre;

  let texto: string;
  if (resultado === 'rescate' && liberado !== null) {
    texto = `${nombre} ha caído justo en el pozo y rescata a ${jugadores[liberado].nombre}.`;
  } else if (resultado === 'condena') {
    texto = `${nombre} ha caído en el pozo y ${otro} ya va por delante, así que se queda dentro tres turnos. Cada vez que se salte su turno, ${otro} le hará una pregunta desde arriba, y podrá lanzarle la cuerda para sacarle antes.`;
  } else {
    texto = `${nombre} ha caído en el pozo y no saldrá hasta que ${otro} lo pase. Mientras tanto, ${otro} le hará una pregunta desde arriba cada vez que se salte su turno, y podrá lanzarle la cuerda para sacarle antes.`;
  }

  return (
    <Caja>
      <Text style={styles.icono}>🕳️</Text>
      <Text style={[styles.titulo, { color: tema.texto }]}>¡Al pozo!</Text>
      <Text style={[styles.texto, { color: tema.textoSuave }]}>{texto}</Text>
      <Pressable style={[styles.boton, { backgroundColor: tema.acento }]} onPress={onTerminar}>
        <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Entendido</Text>
      </Pressable>
    </Caja>
  );
}

const styles = StyleSheet.create({
  icono: { fontSize: 48 },
  titulo: { fontSize: 22, fontWeight: '800', textAlign: 'center' },
  texto: { fontSize: 15, textAlign: 'center' },
  boton: { width: '100%', borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  botonTexto: { fontSize: 17, fontWeight: '700' },
});