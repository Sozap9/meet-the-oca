import type { ReactNode } from 'react';
import { KeyboardAvoidingView, Modal, Platform, StyleSheet, View } from 'react-native';
import { useTema } from '../temas';

// Una única ventana emergente para todo el juego: cambiar de contenido dentro de ella
// evita cerrar una ventana y abrir otra a la vez, que en iPhone puede fallar.
export function Capa({ visible, children }: { visible: boolean; children: ReactNode }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={() => {}}>
      <KeyboardAvoidingView
        style={styles.fondo}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        {children}
      </KeyboardAvoidingView>
    </Modal>
  );
}

// La caja con el aspecto del modo; "grande" es la de las tarjetas
export function Caja({ children, grande = false }: { children: ReactNode; grande?: boolean }) {
  const tema = useTema();
  return (
    <View
      style={[
        styles.caja,
        grande ? styles.cajaGrande : styles.cajaNormal,
        { backgroundColor: tema.tarjeta, borderColor: grande ? tema.cabecera : tema.borde },
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  fondo: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  caja: {
    width: '100%',
    borderWidth: 2,
    borderRadius: 24,
    overflow: 'hidden',
  },
  cajaNormal: { maxWidth: 360, padding: 22, gap: 12, alignItems: 'center' },
  cajaGrande: { maxWidth: 420, minHeight: 440, maxHeight: '90%' },
});