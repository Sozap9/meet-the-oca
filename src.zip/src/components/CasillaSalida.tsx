import { StyleSheet, Text, View } from 'react-native';
import { useTema } from '../temas';
import { REDONDEO_CASILLA } from '../theme';

export function CasillaSalida({ size }: { size: number }) {
  const tema = useTema();
  return (
    <View
      style={[
        styles.celda,
        {
          width: size,
          height: size,
          borderRadius: size * REDONDEO_CASILLA,
          backgroundColor: tema.acento,
        },
      ]}
    >
      <Text
        style={[styles.texto, { fontSize: size * 0.2, color: tema.acentoTexto }]}
        numberOfLines={1}
        adjustsFontSizeToFit
      >
        SALIDA
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  celda: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 2 },
  texto: { fontWeight: '800', letterSpacing: 0.5 },
});