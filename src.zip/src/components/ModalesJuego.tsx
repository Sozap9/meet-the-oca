import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { INFO_CATEGORIA, INFO_TIPO, interaccionDe } from '../data/tarjetas';
import type { Interaccion, Tarjeta } from '../data/tarjetas';
import { OPCIONES_DEBATE, OPCIONES_SEMAFORO } from '../engine/interacciones';
import type { OpcionRonda, TipoRonda } from '../engine/interacciones';
import type { Jugador } from '../engine/juego';
import { useTema } from '../temas';
import { Caja } from './Capa';
import { RondaDoble, SelectorEscala, Temporizador } from './Interacciones';

function tipoDeRonda(interaccion: Interaccion): TipoRonda | null {
  return interaccion.tipo === 'adivinar' ||
    interaccion.tipo === 'semaforo' ||
    interaccion.tipo === 'debate'
    ? interaccion.tipo
    : null;
}

type PropsTarjeta = {
  tarjeta: Tarjeta;
  para: Jugador; // quien recibe la tarjeta
  otro: Jugador; // la otra persona
  pases: number; // pases que le quedan a quien recibe la tarjeta
  onHecho: (respuesta?: string, acierto?: boolean) => void;
  onPasar: () => void;
};

// Pon una "key" distinta en cada tarjeta para que empiece sin respuesta
export function TarjetaContenido({ tarjeta, para, otro, pases, onHecho, onPasar }: PropsTarjeta) {
  const tema = useTema();
  const info = INFO_TIPO[tarjeta.tipo];
  const categoria = tarjeta.categoria ? INFO_CATEGORIA[tarjeta.categoria] : null;
  const interaccion = interaccionDe(tarjeta);
  const esComodin = tarjeta.tipo === 'comodin';
  const sinPases = pases <= 0;

  const [seleccion, setSeleccion] = useState<number | null>(null);
  const [valorEscala, setValorEscala] = useState<number | null>(null);
  const [texto, setTexto] = useState('');
  const [compartir, setCompartir] = useState(true);

  const opciones = interaccion.tipo === 'elegir' ? interaccion.opciones : [];
  const hayOpciones = opciones.length > 0;
  const escribe = interaccion.tipo === 'escribir';
  const tipoRonda = tipoDeRonda(interaccion);
  const faltaElegir =
    (hayOpciones && seleccion === null) ||
    (interaccion.tipo === 'escala' && valorEscala === null);

  const opcionesRonda: OpcionRonda[] =
    interaccion.tipo === 'adivinar'
      ? interaccion.opciones.map((o) => ({ id: o, etiqueta: o }))
      : interaccion.tipo === 'semaforo'
        ? OPCIONES_SEMAFORO
        : OPCIONES_DEBATE;

  const terminar = () => {
    let respuesta: string | undefined;
    if (hayOpciones && seleccion !== null) respuesta = opciones[seleccion];
    else if (interaccion.tipo === 'escala' && valorEscala !== null) {
      respuesta = `${valorEscala} de ${interaccion.max}`;
    } else if (escribe && compartir && texto.trim()) respuesta = texto.trim();
    onHecho(respuesta);
  };

  return (
    <Caja grande>
      <View style={[styles.cabecera, { backgroundColor: tema.cabecera }]}>
        <Text style={styles.icono}>{info.icono}</Text>
        <View style={styles.cabeceraTextos}>
          <Text style={[styles.etiqueta, { color: tema.cabeceraTexto }]}>{info.etiqueta}</Text>
          {categoria ? (
            <Text style={[styles.categoria, { color: tema.cabeceraTexto }]}>
              {categoria.icono} {categoria.nombre}
            </Text>
          ) : null}
        </View>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.cuerpo}
        keyboardShouldPersistTaps="handled"
        bounces={false}
      >
        <View style={styles.paraFila}>
          <View style={[styles.punto, { backgroundColor: para.color }]} />
          <Text style={[styles.para, { color: tema.textoSuave }]}>Para {para.nombre}</Text>
        </View>

        <Text style={[styles.texto, { color: tema.texto }]}>{tarjeta.texto}</Text>

        {hayOpciones ? (
          <View style={styles.opciones}>
            {opciones.map((opcion, i) => {
              const activa = seleccion === i;
              return (
                <Pressable
                  key={opcion}
                  onPress={() => setSeleccion(i)}
                  style={[
                    styles.opcion,
                    {
                      backgroundColor: activa ? tema.opcionActiva : '#ffffff',
                      borderColor: activa ? tema.acento : tema.borde,
                    },
                  ]}
                >
                  <Text style={[styles.opcionTexto, { color: tema.texto }]}>{opcion}</Text>
                  {activa ? <Text style={[styles.check, { color: tema.acento }]}>✓</Text> : null}
                </Pressable>
              );
            })}
          </View>
        ) : null}

        {interaccion.tipo === 'escala' ? (
          <SelectorEscala
            min={interaccion.min}
            max={interaccion.max}
            valor={valorEscala}
            onCambio={setValorEscala}
            etiquetas={interaccion.etiquetas}
          />
        ) : null}

        {interaccion.tipo === 'temporizador' ? <Temporizador segundos={interaccion.segundos} /> : null}

        {escribe ? (
          <View style={styles.escribir}>
            <TextInput
              style={[styles.input, { borderColor: tema.acento, color: tema.texto }]}
              value={texto}
              onChangeText={setTexto}
              placeholder="Escribe aquí…"
              placeholderTextColor={tema.textoSuave}
              multiline
              maxLength={280}
              textAlignVertical="top"
            />
            <Pressable style={styles.compartirFila} onPress={() => setCompartir((c) => !c)}>
              <View
                style={[
                  styles.casilla,
                  { borderColor: tema.acento, backgroundColor: compartir ? tema.acento : 'transparent' },
                ]}
              >
                {compartir ? <Text style={styles.casillaCheck}>✓</Text> : null}
              </View>
              <Text style={[styles.compartirTexto, { color: tema.textoSuave }]}>
                Compartir en el resumen
              </Text>
            </Pressable>
          </View>
        ) : null}

        {tipoRonda ? (
          <RondaDoble
            tipo={tipoRonda}
            opciones={opcionesRonda}
            primero={para}
            segundo={otro}
            pases={pases}
            onPasar={onPasar}
            onTerminar={(respuesta, acierto) => onHecho(respuesta, acierto)}
          />
        ) : info.indicacion ? (
          <Text style={[styles.indicacion, { color: tema.textoSuave }]}>{info.indicacion}</Text>
        ) : null}

        {esComodin ? (
          <Text style={[styles.regalo, { color: tema.acento }]}>🎁 Ganas un pase extra</Text>
        ) : null}
      </ScrollView>

      {tipoRonda ? null : (
        <View style={styles.botones}>
          {esComodin ? (
            <Pressable style={[styles.boton, { backgroundColor: tema.acento }]} onPress={terminar}>
              <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>¡Genial!</Text>
            </Pressable>
          ) : (
            <>
              <Pressable
                style={[
                  styles.boton,
                  { backgroundColor: tema.casillaAlterna },
                  sinPases && styles.botonInactivo,
                ]}
                onPress={onPasar}
                disabled={sinPases}
              >
                <Text style={[styles.botonTexto, { color: tema.texto }]}>
                  {sinPases ? 'Sin pases' : `Pasar (${pases})`}
                </Text>
              </Pressable>
              <Pressable
                style={[
                  styles.boton,
                  { backgroundColor: tema.acento },
                  faltaElegir && styles.botonInactivo,
                ]}
                onPress={terminar}
                disabled={faltaElegir}
              >
                <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Listo</Text>
              </Pressable>
            </>
          )}
        </View>
      )}
    </Caja>
  );
}

type PropsEleccion = {
  quien: Jugador; // quien ha tirado y elige
  para: Jugador; // a quien va dirigida la tarjeta
  onElegir: (cual: 'verdad' | 'reto') => void;
};

export function EleccionContenido({ quien, para, onElegir }: PropsEleccion) {
  const tema = useTema();
  return (
    <Caja>
      <Text style={[styles.titulo, { color: tema.texto }]}>¿Verdad o reto?</Text>
      <Text style={[styles.indicacion, { color: tema.textoSuave }]}>
        {quien.nombre} elige qué le pregunta o le propone a {para.nombre}
      </Text>
      <View style={styles.botonesFila}>
        <Pressable
          style={[styles.boton, { backgroundColor: tema.acento }]}
          onPress={() => onElegir('verdad')}
        >
          <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Verdad</Text>
        </Pressable>
        <Pressable style={[styles.boton, styles.botonReto]} onPress={() => onElegir('reto')}>
          <Text style={[styles.botonTexto, { color: '#ffffff' }]}>Reto</Text>
        </Pressable>
      </View>
    </Caja>
  );
}

const styles = StyleSheet.create({
  cabecera: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    paddingVertical: 12,
  },
  cabeceraTextos: { alignItems: 'flex-start' },
  icono: { fontSize: 26 },
  etiqueta: { fontSize: 16, fontWeight: '700' },
  categoria: { fontSize: 13, fontWeight: '600', opacity: 0.85 },
  scroll: { flexGrow: 1, flexShrink: 1, width: '100%' },
  cuerpo: { flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 22, gap: 16 },
  paraFila: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  punto: { width: 12, height: 12, borderRadius: 6 },
  para: { fontSize: 14, fontWeight: '600' },
  texto: { fontSize: 26, fontWeight: '800', textAlign: 'center' },
  titulo: { fontSize: 24, fontWeight: '800' },
  opciones: { width: '100%', gap: 10 },
  opcion: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 14,
    paddingVertical: 16,
    paddingHorizontal: 12,
  },
  opcionTexto: { fontSize: 20, fontWeight: '700', textAlign: 'center' },
  check: { position: 'absolute', right: 16, fontSize: 20, fontWeight: '800' },
  escribir: { width: '100%', gap: 12 },
  input: {
    minHeight: 110,
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderRadius: 14,
    padding: 12,
    fontSize: 17,
  },
  compartirFila: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  casilla: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  casillaCheck: { color: '#ffffff', fontSize: 14, fontWeight: '800' },
  compartirTexto: { fontSize: 14, fontWeight: '600' },
  indicacion: { fontSize: 13, textAlign: 'center' },
  regalo: { fontSize: 16, fontWeight: '700' },
  botones: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    paddingHorizontal: 22,
    paddingBottom: 22,
    paddingTop: 6,
  },
  botonesFila: { flexDirection: 'row', gap: 12, marginTop: 4 },
  boton: { paddingVertical: 14, paddingHorizontal: 30, borderRadius: 14, minWidth: 120, alignItems: 'center' },
  botonReto: { backgroundColor: '#c0504d' },
  botonInactivo: { opacity: 0.4 },
  botonTexto: { fontSize: 17, fontWeight: '700' },
});