import { memo, useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import {
  CARAS,
  aCuaternion,
  aplicar,
  cruz,
  deCuaternion,
  multiplicar,
  normalizar,
  orientacionFinal,
  punto,
  rotacionAleatoria,
  rotar,
  slerp,
  ejeAleatorio,
} from '../engine/dado3d';
import type { Mat, Vec } from '../engine/dado3d';

// Ajustes de la animación y del aspecto
const DURACION_TIRADA = 1500; // ms
const PAUSA_FINAL = 500; // ms quieto mostrando el resultado
const REBOTES = 3;
const PERSPECTIVA = 5; // distancia de la cámara en lados del dado; 0 = sin perspectiva
const SOLAPE = 1.03; // las caras se solapan un poco para que no queden huecos
const LUZ = normalizar([-0.35, -0.55, 0.75]); // de dónde viene la luz (arriba a la izquierda)
const DOS_PI = Math.PI * 2;

export interface TiradaEnCurso {
  id: number;
  valor: number;
  inclinacion?: number;
}

// Aspecto de una cara: color de fondo y, si lo hay, un icono; sin icono lleva los puntos
export interface CaraVisual {
  fondo: string;
  icono?: string;
}

export const CARAS_CLASICAS: CaraVisual[] = Array.from({ length: 6 }, () => ({ fondo: '#ffffff' }));

// Oscurece o aclara un color "#rrggbb"
function sombrear(hex: string, factor: number): string {
  const n = parseInt(hex.slice(1), 16);
  const canal = (desplazamiento: number) =>
    Math.max(0, Math.min(255, Math.round(((n >> desplazamiento) & 255) * factor)));
  return `rgb(${canal(16)}, ${canal(8)}, ${canal(0)})`;
}

// Posición (fila, columna) de cada punto en una cuadrícula de 3×3
const PUNTOS: Record<number, [number, number][]> = {
  1: [[1, 1]],
  2: [[0, 0], [2, 2]],
  3: [[0, 0], [1, 1], [2, 2]],
  4: [[0, 0], [0, 2], [2, 0], [2, 2]],
  5: [[0, 0], [0, 2], [1, 1], [2, 0], [2, 2]],
  6: [[0, 0], [0, 2], [1, 0], [1, 2], [2, 0], [2, 2]],
};

const Puntos = memo(function Puntos({ valor, size }: { valor: number; size: number }) {
  const margen = size * 0.2;
  const tamPunto = size * 0.17;
  const paso = (size - margen * 2 - tamPunto) / 2;
  return (
    <>
      {PUNTOS[valor].map(([fila, columna], i) => (
        <View
          key={i}
          style={{
            position: 'absolute',
            width: tamPunto,
            height: tamPunto,
            borderRadius: tamPunto / 2,
            backgroundColor: '#20242d',
            left: margen + columna * paso,
            top: margen + fila * paso,
          }}
        />
      ))}
    </>
  );
});

type PropsCubo = {
  rotacion: Mat;
  size: number;
  caras: CaraVisual[];
  altura?: number; // cuánto se acerca a la cámara (al botar)
  escala?: number;
};

// Dibuja el cubo: cada cara tiene su propia matriz 3D completa, con perspectiva
function CuboDado({ rotacion, size, caras, altura = 0, escala = 1 }: PropsCubo) {
  const H = size / 2;
  const d = PERSPECTIVA > 0 ? size * PERSPECTIVA : Infinity;
  // Compensación para que la cara frontal, en reposo, mida exactamente `size`
  const comp = 1 / (1 + H / d);
  const k = escala * comp;

  return (
    <View style={{ width: size, height: size }}>
      {CARAS.map((geo) => {
        const ru = aplicar(rotacion, geo.u);
        const rv = aplicar(rotacion, geo.v);
        const rn = aplicar(rotacion, geo.n);
        // Ejes en el marco de pantalla (y hacia abajo, z hacia el jugador)
        const us: Vec = [ru[0], -ru[1], ru[2]];
        const ds: Vec = [-rv[0], rv[1], -rv[2]];
        const ns: Vec = [rn[0], -rn[1], rn[2]];

        const visible = ns[2] > H / d; // solo las caras que miran a la cámara
        const luz = 0.66 + 0.4 * Math.max(0, punto(ns, LUZ));
        const visual = caras[geo.valor - 1] ?? caras[0];

        const normal = cruz(us, ds);
        const c0: Vec = [us[0] * k * SOLAPE, us[1] * k * SOLAPE, us[2] * k * SOLAPE];
        const c1: Vec = [ds[0] * k * SOLAPE, ds[1] * k * SOLAPE, ds[2] * k * SOLAPE];
        const c2: Vec = [normal[0] * k, normal[1] * k, normal[2] * k];
        const c3: Vec = [k * H * ns[0], k * H * ns[1], k * H * ns[2] + altura];
        const matrix = [
          c0[0], c0[1], c0[2], -c0[2] / d,
          c1[0], c1[1], c1[2], -c1[2] / d,
          c2[0], c2[1], c2[2], -c2[2] / d,
          c3[0], c3[1], c3[2], 1 - c3[2] / d,
        ];

        return (
          <View
            key={geo.valor}
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: size,
              height: size,
              borderRadius: size * 0.13,
              backgroundColor: sombrear(visual.fondo, luz * 0.9),
              borderWidth: size * 0.014,
              borderColor: sombrear(visual.fondo, luz * 0.68),
              alignItems: 'center',
              justifyContent: 'center',
              opacity: visible ? 1 : 0,
              transform: [{ matrix }],
            }}
          >
            <View
              style={{
                position: 'absolute',
                left: size * 0.06,
                top: size * 0.06,
                right: size * 0.06,
                bottom: size * 0.06,
                borderRadius: size * 0.09,
                backgroundColor: sombrear(visual.fondo, luz * 1.02),
              }}
            />
            {visual.icono ? (
              <Text style={{ fontSize: size * 0.46 }}>{visual.icono}</Text>
            ) : (
              <Puntos valor={geo.valor} size={size} />
            )}
          </View>
        );
      })}
    </View>
  );
}

function SombraSuelo({ size, desplazamiento = 0, rebote = 0 }: { size: number; desplazamiento?: number; rebote?: number }) {
  return (
    <View
      style={{
        position: 'absolute',
        left: size * 0.05 + desplazamiento,
        top: size * 0.72,
        width: size * 0.9,
        height: size * 0.26,
        borderRadius: size,
        backgroundColor: '#000000',
        opacity: 0.22 * (1 - 0.6 * rebote),
        transform: [{ scaleX: 1 - 0.4 * rebote }],
      }}
    />
  );
}

// ---------- Dado quieto ----------

type PropsReposo = {
  valor: number;
  size: number;
  inclinacion?: number;
  caras?: CaraVisual[];
};

export function DadoReposo({ valor, size, inclinacion = 0.12, caras = CARAS_CLASICAS }: PropsReposo) {
  return (
    <View style={{ width: size, height: size }}>
      <SombraSuelo size={size} />
      <CuboDado rotacion={orientacionFinal(valor, inclinacion)} size={size} caras={caras} />
    </View>
  );
}

// ---------- Dado lanzándose ----------

type PropsAnimado = {
  valor: number;
  size: number;
  onTerminar: () => void;
  inclinacion?: number; // inclinación con la que se asienta
  desde?: { valor: number; inclinacion: number }; // cómo estaba antes de lanzarlo
  entrada?: 'lado' | 'centro'; // entra volando desde un lado o se lanza en su sitio
  caras?: CaraVisual[];
};

export function DadoAnimado({
  valor,
  size,
  onTerminar,
  inclinacion,
  desde,
  entrada = 'lado',
  caras = CARAS_CLASICAS,
}: PropsAnimado) {
  const { width: ancho } = useWindowDimensions();
  const alTerminar = useRef(onTerminar);
  alTerminar.current = onTerminar;

  const [p, setP] = useState(0); // progreso de la animación, de 0 a 1

  // Azar de esta tirada: se fija una sola vez
  const [azar] = useState(() => ({
    lado: Math.random() < 0.5 ? -1 : 1, // por qué lado entra
    eje1: ejeAleatorio(),
    eje2: ejeAleatorio(),
    vueltas1: 2 + Math.floor(Math.random() * 2), // vueltas completas
    vueltas2: 1 + Math.floor(Math.random() * 2),
    inclinacion: inclinacion ?? (Math.random() - 0.5) * 0.4,
    inicio: desde ? orientacionFinal(desde.valor, desde.inclinacion) : rotacionAleatoria(),
  }));

  useEffect(() => {
    const inicio = Date.now();
    let cuadro = 0;
    let espera: ReturnType<typeof setTimeout> | undefined;

    const paso = () => {
      const progreso = Math.min((Date.now() - inicio) / DURACION_TIRADA, 1);
      setP(progreso);
      if (progreso < 1) {
        cuadro = requestAnimationFrame(paso);
      } else {
        espera = setTimeout(() => alTerminar.current(), PAUSA_FINAL);
      }
    };
    cuadro = requestAnimationFrame(paso);

    return () => {
      cancelAnimationFrame(cuadro);
      if (espera) clearTimeout(espera);
    };
  }, [valor]);

  // Orientación: de la inicial a la final, con vueltas completas por encima.
  // Las vueltas son enteras, así que al final no alteran la orientación.
  const final = orientacionFinal(valor, azar.inclinacion);
  const suave = p * p * (3 - 2 * p);
  const base = deCuaternion(slerp(aCuaternion(azar.inicio), aCuaternion(final), suave));
  const f1 = 1 - Math.pow(1 - p, 2.2);
  const f2 = 1 - Math.pow(1 - p, 1.8);
  let rotacion = multiplicar(
    rotar(azar.eje2, DOS_PI * azar.vueltas2 * f2),
    multiplicar(rotar(azar.eje1, DOS_PI * azar.vueltas1 * f1), base),
  );

  // Pequeño balanceo al asentarse
  const t = Math.max(0, (p - 0.78) / 0.22);
  const amortiguacion = Math.pow(1 - t, 2);
  const balanceo = 0.1 * Math.sin(t * Math.PI * 5) * amortiguacion;
  rotacion = multiplicar(
    rotar([1, 0, 0], balanceo),
    multiplicar(rotar([0, 1, 0], balanceo * 0.7), rotacion),
  );

  // Rebotes: 0 en el suelo, hasta 1 en lo más alto; cada vez más bajos
  const resto = Math.pow(1 - p, 1.6);
  const rebote = Math.abs(Math.sin(Math.PI * REBOTES * p)) * resto;
  const altura = rebote * size * 1.6;
  const x = entrada === 'lado' ? azar.lado * ancho * 0.6 * Math.pow(1 - p, 2) : 0;
  const y = -rebote * size * 0.45;
  const escala = 1 + 0.04 * Math.sin(Math.PI * p);
  const aparece = entrada === 'lado' ? Math.min(1, p / 0.08) : 1;

  return (
    <View style={{ width: size, height: size, opacity: aparece }}>
      <SombraSuelo size={size} desplazamiento={x} rebote={rebote} />
      <View style={{ transform: [{ translateX: x }, { translateY: y }] }}>
        <CuboDado rotacion={rotacion} size={size} caras={caras} altura={altura} escala={escala} />
      </View>
    </View>
  );
}