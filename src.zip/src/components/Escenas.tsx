import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { Intensidad, Tarjeta, TipoTarjeta } from '../data/tarjetas';
import { CASILLAS_APUESTA, perdedorDeDados } from '../engine/dados';
import { retroceder, tirarDado } from '../engine/juego';
import type { EstadoJuego, Jugador } from '../engine/juego';
import { TIPOS_LIGERA, TIPOS_RETO, TIPOS_VERDAD } from '../engine/mazos';
import { useTema } from '../temas';
import { Caja } from './Capa';
import { DadoAnimado, DadoReposo } from './Dado';
import { TarjetaContenido } from './ModalesJuego';

// Lo que necesitan las escenas de la partida
export interface Servicios {
  jugadores: Jugador[];
  pases: number[];
  intensidad: Intensidad; // la que toca según el avance de la partida
  robar: (tipos?: TipoTarjeta[], intensidad?: Intensidad) => Tarjeta | null;
  registrar: (
    jugador: number,
    tarjeta: Tarjeta,
    resultado: 'hecha' | 'pasada',
    respuesta?: string,
    acierto?: boolean,
  ) => void;
  actualizar: (cambio: (estado: EstadoJuego) => EstadoJuego) => void;
}

// ---------- Piezas comunes ----------

function Cabecera({ icono, titulo, texto }: { icono: string; titulo: string; texto: string }) {
  const tema = useTema();
  return (
    <>
      <Text style={styles.icono}>{icono}</Text>
      <Text style={[styles.titulo, { color: tema.texto }]}>{titulo}</Text>
      <Text style={[styles.texto, { color: tema.textoSuave }]}>{texto}</Text>
    </>
  );
}

function Boton({
  texto,
  descripcion,
  onPress,
  principal = false,
  desactivado = false,
}: {
  texto: string;
  descripcion?: string;
  onPress: () => void;
  principal?: boolean;
  desactivado?: boolean;
}) {
  const tema = useTema();
  return (
    <Pressable
      style={[
        styles.boton,
        { backgroundColor: principal ? tema.acento : tema.casillaAlterna },
        desactivado && styles.desactivado,
      ]}
      onPress={onPress}
      disabled={desactivado}
    >
      <Text style={[styles.botonTexto, { color: principal ? tema.acentoTexto : tema.texto }]}>
        {texto}
      </Text>
      {descripcion ? (
        <Text
          style={[styles.botonDescripcion, { color: principal ? tema.acentoTexto : tema.textoSuave }]}
        >
          {descripcion}
        </Text>
      ) : null}
    </Pressable>
  );
}

// Muestra una tarjeta a una persona y avisa de si la hizo (true) o la pasó (false)
function PasoTarjeta({
  tarjeta,
  para,
  servicios,
  onFin,
}: {
  tarjeta: Tarjeta;
  para: number;
  servicios: Servicios;
  onFin: (hecha: boolean) => void;
}): ReactNode {
  const { jugadores, pases, registrar } = servicios;
  return (
    <TarjetaContenido
      tarjeta={tarjeta}
      para={jugadores[para]}
      otro={jugadores[(para + 1) % jugadores.length]}
      pases={pases[para]}
      onHecho={(respuesta, acierto) => {
        registrar(para, tarjeta, 'hecha', respuesta, acierto);
        onFin(true);
      }}
      onPasar={() => {
        registrar(para, tarjeta, 'pasada');
        onFin(false);
      }}
    />
  );
}

// ---------- Posada: pagarla con una pregunta o perder un turno ----------

export function EscenaPosada({
  jugador,
  servicios,
  onTerminar,
}: {
  jugador: number;
  servicios: Servicios;
  onTerminar: (pagada: boolean) => void;
}) {
  const [tarjeta, setTarjeta] = useState<Tarjeta | null>(null);

  if (tarjeta) {
    return <PasoTarjeta tarjeta={tarjeta} para={jugador} servicios={servicios} onFin={onTerminar} />;
  }

  const pagar = () => {
    const nueva = servicios.robar(TIPOS_VERDAD, 2);
    if (nueva) setTarjeta(nueva);
    else onTerminar(false);
  };

  return (
    <Caja>
      <Cabecera
        icono="🛏️"
        titulo="La posada"
        texto={`${servicios.jugadores[jugador].nombre} puede pagar la posada contestando una pregunta, o descansar y perder un turno.`}
      />
      <Boton principal texto="Contestar una pregunta" descripcion="No pierdes el turno" onPress={pagar} />
      <Boton texto="Perder un turno" onPress={() => onTerminar(false)} />
    </Caja>
  );
}

// ---------- Cárcel: fianza con pregunta profunda o con un reto que elige el carcelero ----------

export function EscenaCarcel({
  jugador,
  servicios,
  onTerminar,
}: {
  jugador: number;
  servicios: Servicios;
  onTerminar: (libre: boolean) => void;
}) {
  const [fase, setFase] = useState<'elegir' | 'fianza' | 'carcelero' | 'tarjeta'>('elegir');
  const [tarjeta, setTarjeta] = useState<Tarjeta | null>(null);
  const [retos, setRetos] = useState<Tarjeta[]>([]);

  const { jugadores } = servicios;
  const nombre = jugadores[jugador].nombre;
  const carcelero = jugadores[(jugador + 1) % jugadores.length];

  const fianzaConPregunta = () => {
    const nueva = servicios.robar(TIPOS_VERDAD, 3);
    if (!nueva) {
      onTerminar(false);
      return;
    }
    setTarjeta(nueva);
    setFase('tarjeta');
  };

  const fianzaConReto = () => {
    const lista: Tarjeta[] = [];
    for (let i = 0; i < 10 && lista.length < 4; i++) {
      const reto = servicios.robar(TIPOS_RETO);
      if (reto && !lista.some((r) => r.texto === reto.texto)) lista.push(reto);
    }
    if (lista.length === 0) {
      onTerminar(false);
      return;
    }
    setRetos(lista);
    setFase('carcelero');
  };

  if (fase === 'tarjeta' && tarjeta) {
    return <PasoTarjeta tarjeta={tarjeta} para={jugador} servicios={servicios} onFin={onTerminar} />;
  }

  if (fase === 'carcelero') {
    return (
      <Caja>
        <Cabecera
          icono="🗝️"
          titulo="El carcelero"
          texto={`${carcelero.nombre} elige el reto que libera a ${nombre}.`}
        />
        {retos.map((reto) => (
          <Boton
            key={reto.texto}
            texto={reto.texto}
            onPress={() => {
              setTarjeta(reto);
              setFase('tarjeta');
            }}
          />
        ))}
      </Caja>
    );
  }

  if (fase === 'fianza') {
    return (
      <Caja>
        <Cabecera icono="💰" titulo="La fianza" texto={`¿Con qué paga la fianza ${nombre}?`} />
        <Boton
          principal
          texto="Una pregunta profunda"
          descripcion="Una tarjeta de las más íntimas"
          onPress={fianzaConPregunta}
        />
        <Boton
          texto="Un reto"
          descripcion={`${carcelero.nombre} elige cuál`}
          onPress={fianzaConReto}
        />
      </Caja>
    );
  }

  return (
    <Caja>
      <Cabecera
        icono="⛓️"
        titulo="¡A la cárcel!"
        texto={`${nombre} puede cumplir la condena de dos turnos o pagar la fianza.`}
      />
      <Boton principal texto="Pagar la fianza" onPress={() => setFase('fianza')} />
      <Boton texto="Cumplir la condena" descripcion="Pierdes dos turnos" onPress={() => onTerminar(false)} />
    </Caja>
  );
}

// ---------- Dados: duelo o apuesta ----------

export function EscenaDados({
  jugador,
  servicios,
  onTerminar,
}: {
  jugador: number;
  servicios: Servicios;
  onTerminar: () => void;
}) {
  const tema = useTema();
  const { jugadores } = servicios;
  const [modo, setModo] = useState<'duelo' | 'apuesta' | null>(null);
  const [fase, setFase] = useState<'elegir' | 'tirar' | 'resultado' | 'tarjeta'>('elegir');
  const [ronda, setRonda] = useState<{
    id: number;
    valores: number[];
    inclinaciones: number[];
  } | null>(null);
  const [terminados, setTerminados] = useState(0);
  const [reposo, setReposo] = useState(() =>
    jugadores.map((_, i) => ({ valor: 1, inclinacion: i % 2 === 0 ? 0.12 : -0.12 })),
  );
  const [resultado, setResultado] = useState<{ valores: number[]; perdedor: number | null } | null>(
    null,
  );
  const [tarjeta, setTarjeta] = useState<Tarjeta | null>(null);
  const contador = useRef(0);

  // Cuando todos los dados han terminado de rodar, se mira quién ha perdido
  useEffect(() => {
    if (!ronda || terminados < ronda.valores.length) return;
    setReposo(ronda.valores.map((valor, i) => ({ valor, inclinacion: ronda.inclinaciones[i] })));
    const perdedor = perdedorDeDados(ronda.valores);
    setResultado({ valores: ronda.valores, perdedor });
    setFase(perdedor === null ? 'tirar' : 'resultado');
    setRonda(null);
    setTerminados(0);
  }, [terminados, ronda]);

  const tirar = () => {
    contador.current += 1;
    setTerminados(0);
    setResultado(null);
    setRonda({
      id: contador.current,
      valores: jugadores.map(() => tirarDado()),
      inclinaciones: jugadores.map(() => (Math.random() - 0.5) * 0.4),
    });
  };

  const continuar = () => {
    if (!resultado || resultado.perdedor === null) return;
    const perdedor = resultado.perdedor;
    if (modo === 'apuesta') {
      servicios.actualizar((estado) => retroceder(estado, perdedor, CASILLAS_APUESTA));
    }
    const nueva =
      modo === 'duelo' ? servicios.robar(TIPOS_VERDAD, 3) : servicios.robar(TIPOS_LIGERA, 1);
    if (nueva) {
      setTarjeta(nueva);
      setFase('tarjeta');
    } else {
      onTerminar();
    }
  };

  if (fase === 'tarjeta' && tarjeta && resultado && resultado.perdedor !== null) {
    return (
      <PasoTarjeta
        tarjeta={tarjeta}
        para={resultado.perdedor}
        servicios={servicios}
        onFin={() => onTerminar()}
      />
    );
  }

  if (fase === 'elegir') {
    return (
      <Caja>
        <Cabecera
          icono="🎲"
          titulo="Dados"
          texto={`${jugadores[jugador].nombre}, elige cómo jugáis esta casilla.`}
        />
        <Boton
          principal
          texto="⚔️ Duelo"
          descripcion="Tiráis los dos: quien saque menos contesta una pregunta íntima"
          onPress={() => {
            setModo('duelo');
            setFase('tirar');
          }}
        />
        <Boton
          texto="🎰 Apuesta"
          descripcion={`Tiráis los dos: quien saque menos retrocede ${CASILLAS_APUESTA} casillas y contesta una pregunta ligera`}
          onPress={() => {
            setModo('apuesta');
            setFase('tirar');
          }}
        />
      </Caja>
    );
  }

  const perdedorNombre =
    resultado && resultado.perdedor !== null ? jugadores[resultado.perdedor].nombre : null;

  return (
    <Caja>
      <Text style={[styles.titulo, { color: tema.texto }]}>
        {modo === 'duelo' ? '⚔️ Duelo de dados' : '🎰 Apuesta de dados'}
      </Text>

      <View style={styles.dados}>
        {jugadores.map((j, i) => (
          <View key={j.id} style={styles.dadoColumna}>
            <View style={styles.dadoCaja}>
              {ronda ? (
                <DadoAnimado
                  key={`${ronda.id}-${i}`}
                  valor={ronda.valores[i]}
                  size={70}
                  inclinacion={ronda.inclinaciones[i]}
                  desde={reposo[i]}
                  entrada="centro"
                  onTerminar={() => setTerminados((n) => n + 1)}
                />
              ) : (
                <DadoReposo valor={reposo[i].valor} inclinacion={reposo[i].inclinacion} size={70} />
              )}
            </View>
            <View style={styles.fila}>
              <View style={[styles.punto, { backgroundColor: j.color }]} />
              <Text style={[styles.nombre, { color: tema.texto }]}>{j.nombre}</Text>
            </View>
          </View>
        ))}
      </View>

      {fase === 'resultado' && resultado && perdedorNombre ? (
        <>
          <Text style={[styles.resultado, { color: tema.texto }]}>
            {jugadores.map((j, i) => `${j.nombre} sacó ${resultado.valores[i]}`).join(' · ')}
          </Text>
          <Text style={[styles.resultado, { color: tema.acento }]}>
            {modo === 'duelo'
              ? `${perdedorNombre} saca menos y contesta una pregunta íntima`
              : `${perdedorNombre} saca menos: retrocede ${CASILLAS_APUESTA} casillas y contesta una pregunta ligera`}
          </Text>
          <Boton principal texto="Continuar" onPress={continuar} />
        </>
      ) : (
        <>
          {resultado && resultado.perdedor === null ? (
            <Text style={[styles.resultado, { color: tema.acento }]}>¡Empate! Hay que repetir.</Text>
          ) : null}
          <Boton
            principal
            texto={resultado ? '🎲 Tirar otra vez' : '🎲 Tirar los dos'}
            onPress={tirar}
            desactivado={ronda !== null}
          />
        </>
      )}
    </Caja>
  );
}

// ---------- Pozo: pregunta desde arriba ----------

export function EscenaPozoArriba({
  preso,
  servicios,
  onTerminar,
}: {
  preso: number;
  servicios: Servicios;
  onTerminar: () => void;
}) {
  const [tarjeta, setTarjeta] = useState<Tarjeta | null>(null);
  const { jugadores } = servicios;
  const arriba = jugadores[(preso + 1) % jugadores.length];

  if (tarjeta) {
    return <PasoTarjeta tarjeta={tarjeta} para={preso} servicios={servicios} onFin={() => onTerminar()} />;
  }

  const escuchar = () => {
    const nueva = servicios.robar(TIPOS_VERDAD, servicios.intensidad);
    if (nueva) setTarjeta(nueva);
    else onTerminar();
  };

  return (
    <Caja>
      <Cabecera
        icono="🕳️"
        titulo="Desde arriba"
        texto={`${arriba.nombre} se asoma al pozo y le hace una pregunta a ${jugadores[preso].nombre}.`}
      />
      <Boton principal texto="Escuchar la pregunta" onPress={escuchar} />
    </Caja>
  );
}

// ---------- Pozo: la cuerda ----------

export function EscenaCuerda({
  rescatador,
  preso,
  servicios,
  onTerminar,
}: {
  rescatador: number;
  preso: number;
  servicios: Servicios;
  onTerminar: (rescatado: boolean) => void;
}) {
  const [tarjeta, setTarjeta] = useState<Tarjeta | null>(null);
  const { jugadores } = servicios;

  if (tarjeta) {
    return <PasoTarjeta tarjeta={tarjeta} para={rescatador} servicios={servicios} onFin={onTerminar} />;
  }

  const lanzar = () => {
    const nueva = servicios.robar(TIPOS_VERDAD, 3);
    if (nueva) setTarjeta(nueva);
    else onTerminar(false);
  };

  return (
    <Caja>
      <Cabecera
        icono="🪢"
        titulo="La cuerda"
        texto={`${jugadores[rescatador].nombre} puede rescatar al instante a ${jugadores[preso].nombre} si contesta una pregunta íntima.`}
      />
      <Boton principal texto="Lanzar la cuerda" onPress={lanzar} />
      <Boton texto="Mejor no" onPress={() => onTerminar(false)} />
    </Caja>
  );
}

const styles = StyleSheet.create({
  icono: { fontSize: 48 },
  titulo: { fontSize: 22, fontWeight: '800', textAlign: 'center' },
  texto: { fontSize: 15, textAlign: 'center' },
  boton: {
    width: '100%',
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 14,
    alignItems: 'center',
    gap: 2,
  },
  desactivado: { opacity: 0.45 },
  botonTexto: { fontSize: 17, fontWeight: '700', textAlign: 'center' },
  botonDescripcion: { fontSize: 13, textAlign: 'center' },
  dados: { flexDirection: 'row', justifyContent: 'center', gap: 28 },
  dadoColumna: { alignItems: 'center', gap: 4 },
  dadoCaja: { width: 90, height: 120, alignItems: 'center', justifyContent: 'center' },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  punto: { width: 12, height: 12, borderRadius: 6 },
  nombre: { fontSize: 14, fontWeight: '700' },
  resultado: { fontSize: 16, fontWeight: '700', textAlign: 'center' },
});