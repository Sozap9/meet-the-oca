import { Pressable, StyleSheet, Text } from 'react-native';
import type { Resumen } from '../engine/resumen';
import { useTema } from '../temas';
import { Caja } from './Capa';

function Boton({
  texto,
  onPress,
  principal = false,
}: {
  texto: string;
  onPress: () => void;
  principal?: boolean;
}) {
  const tema = useTema();
  return (
    <Pressable
      style={[styles.boton, { backgroundColor: principal ? tema.acento : tema.casillaAlterna }]}
      onPress={onPress}
    >
      <Text style={[styles.botonTexto, { color: principal ? tema.acentoTexto : tema.texto }]}>
        {texto}
      </Text>
    </Pressable>
  );
}

type PropsFin = {
  total: number;
  resumen: Resumen;
  onOtraVez: () => void;
  onResumen: () => void;
  onSalir: () => void;
};

export function FinDadoContenido({ total, resumen, onOtraVez, onResumen, onSalir }: PropsFin) {
  const tema = useTema();
  return (
    <Caja>
      <Text style={styles.emoji}>🎉</Text>
      <Text style={[styles.titulo, { color: tema.texto }]}>¡Partida completada!</Text>
      <Text style={[styles.subtitulo, { color: tema.textoSuave }]}>
        {total} tiradas · {resumen.totalHechas} tarjetas hechas · {resumen.totalPasadas} pasadas
      </Text>
      {resumen.sintonia ? (
        <Text style={[styles.subtitulo, { color: tema.acento }]}>
          Sintonía: {resumen.sintonia.aciertos} de {resumen.sintonia.total}
        </Text>
      ) : null}
      <Boton texto="Jugar otra vez" onPress={onOtraVez} principal />
      <Boton texto="📋 Ver resumen" onPress={onResumen} />
      <Boton texto="Salir al inicio" onPress={onSalir} />
    </Caja>
  );
}

const styles = StyleSheet.create({
  boton: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', width: '100%' },
  botonTexto: { fontSize: 16, fontWeight: '700' },
  emoji: { fontSize: 52 },
  titulo: { fontSize: 24, fontWeight: '800', textAlign: 'center' },
  subtitulo: { fontSize: 14, textAlign: 'center' },
});