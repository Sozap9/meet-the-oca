import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { EstadoJuego } from '../engine/juego';
import { useTema } from '../temas';

// Una línea del historial de turnos
export interface LineaHistorial {
  id: string;
  jugador: number;
  texto: string;
}

type Props = {
  estado: EstadoJuego;
  pases: number[];
  tirando: boolean;
  bloqueado: boolean;
  accion?: { texto: string; onPress: () => void };
  historial?: LineaHistorial[];
  onTirar: () => void;
  onReiniciar: () => void;
};

export function PanelTurno({
  estado,
  pases,
  tirando,
  bloqueado,
  accion,
  historial = [],
  onTirar,
  onReiniciar,
}: Props) {
  const tema = useTema();
  const ganador = estado.ganador !== null ? estado.jugadores[estado.ganador] : null;
  const jugador = estado.jugadores[estado.turno];
  const disponibles = pases[estado.turno] ?? 0;
  const inactivo = tirando || bloqueado;

  return (
    <View style={styles.panel}>
      {/* 1 y 2: de quién es el turno y cuántos pases tiene */}
      {ganador ? (
        <Text style={[styles.turnoTexto, { color: tema.texto }]}>🏆 ¡{ganador.nombre} gana!</Text>
      ) : (
        <>
          <View style={styles.turno}>
            <View style={[styles.punto, { backgroundColor: jugador.color }]} />
            <Text style={[styles.turnoTexto, { color: tema.texto }]}>Turno de {jugador.nombre}</Text>
          </View>
          <Text style={[styles.pases, { color: tema.textoSuave }]}>
            {disponibles} {disponibles === 1 ? 'pase disponible' : 'pases disponibles'}
          </Text>
        </>
      )}

      {/* Acción opcional (la cuerda) */}
      {accion && !ganador ? (
        <Pressable
          onPress={accion.onPress}
          disabled={inactivo}
          style={[styles.accion, { borderColor: tema.acento, opacity: inactivo ? 0.5 : 1 }]}
        >
          <Text style={[styles.accionTexto, { color: tema.texto }]}>{accion.texto}</Text>
        </Pressable>
      ) : null}

      {/* 3: tirar dado */}
      {ganador ? (
        <Pressable onPress={onReiniciar} style={[styles.boton, { backgroundColor: tema.acento }]}>
          <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Jugar otra vez</Text>
        </Pressable>
      ) : (
        <Pressable
          onPress={onTirar}
          disabled={inactivo}
          style={[styles.boton, { backgroundColor: tema.acento, opacity: inactivo ? 0.5 : 1 }]}
        >
          <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>
            {tirando ? '🎲 Tirando…' : '🎲 Tirar dado'}
          </Text>
        </Pressable>
      )}

      {/* 4: historial de turnos, lo más nuevo arriba */}
      <View style={[styles.historialCaja, { borderTopColor: tema.centroBorde }]}>
        <Text style={[styles.historialTitulo, { color: tema.textoSuave }]}>Historial de turnos</Text>
        <ScrollView
          style={styles.historial}
          nestedScrollEnabled
          showsVerticalScrollIndicator={false}
        >
          {historial.length === 0 ? (
            <Text style={[styles.lineaTexto, { color: tema.textoSuave }]}>
              Aquí irán los movimientos de los dos.
            </Text>
          ) : (
            historial.map((linea, i) => (
              <View
                key={linea.id}
                style={[styles.linea, { opacity: Math.max(0.4, 1 - i * 0.15) }]}
              >
                <View
                  style={[
                    styles.lineaPunto,
                    { backgroundColor: estado.jugadores[linea.jugador].color },
                  ]}
                />
                <Text style={[styles.lineaTexto, { color: tema.textoSuave }]} numberOfLines={2}>
                  {linea.texto}
                </Text>
              </View>
            ))
          )}
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: { width: '100%', alignItems: 'center', paddingHorizontal: 16, paddingTop: 8 },
  turno: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  punto: { width: 14, height: 14, borderRadius: 7 },
  turnoTexto: { fontSize: 18, fontWeight: '800' },
  pases: { fontSize: 13, fontWeight: '600', marginTop: 2 },
  accion: {
    marginTop: 8,
    paddingVertical: 8,
    paddingHorizontal: 18,
    borderRadius: 999,
    borderWidth: 2,
  },
  accionTexto: { fontSize: 14, fontWeight: '700' },
  boton: {
    marginTop: 8,
    paddingVertical: 12,
    paddingHorizontal: 36,
    borderRadius: 999,
  },
  botonTexto: { fontSize: 18, fontWeight: '800' },
  historialCaja: {
    width: '100%',
    marginTop: 10,
    paddingTop: 6,
    borderTopWidth: 1,
  },
  historialTitulo: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  historial: { height: 60 },
  linea: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 2 },
  lineaPunto: { width: 8, height: 8, borderRadius: 4 },
  lineaTexto: { flex: 1, fontSize: 12, lineHeight: 15 },
});