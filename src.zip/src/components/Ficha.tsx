import { StyleSheet, View } from 'react-native';

type Props = { color: string; size: number };

export function Ficha({ color, size }: Props) {
  return (
    <View
      style={[
        styles.ficha,
        { width: size, height: size, borderRadius: size / 2, backgroundColor: color },
      ]}
    />
  );
}

const styles = StyleSheet.create({
  ficha: {
    borderWidth: 2,
    borderColor: '#ffffff',
    shadowColor: '#000000',
    shadowOpacity: 0.3,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 },
    elevation: 3,
  },
});