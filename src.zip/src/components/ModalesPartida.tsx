import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { INFO_TIPO } from '../data/tarjetas';
import type { Jugador } from '../engine/juego';
import { textoTarjeta } from '../engine/resumen';
import type { Resumen } from '../engine/resumen';
import { useTema } from '../temas';
import { Caja } from './Capa';

function Boton({
  texto,
  onPress,
  principal = false,
}: {
  texto: string;
  onPress: () => void;
  principal?: boolean;
}) {
  const tema = useTema();
  return (
    <Pressable
      style={[styles.boton, { backgroundColor: principal ? tema.acento : tema.casillaAlterna }]}
      onPress={onPress}
    >
      <Text style={[styles.botonTexto, { color: principal ? tema.acentoTexto : tema.texto }]}>
        {texto}
      </Text>
    </Pressable>
  );
}

type PropsMenu = {
  onReglas: () => void;
  onResumen: () => void;
  onReiniciar: () => void;
  onSalir: () => void;
  onCerrar: () => void;
};

export function MenuContenido({ onReglas, onResumen, onReiniciar, onSalir, onCerrar }: PropsMenu) {
  return (
    <Caja>
      <Boton texto="📖 Ver reglas" onPress={onReglas} />
      <Boton texto="📋 Resumen hasta ahora" onPress={onResumen} />
      <Boton texto="🔄 Reiniciar partida" onPress={onReiniciar} />
      <Boton texto="🚪 Salir al inicio" onPress={onSalir} />
      <Boton texto="Seguir jugando" onPress={onCerrar} principal />
    </Caja>
  );
}

type PropsVictoria = {
  ganador: Jugador;
  onOtraVez: () => void;
  onResumen: () => void;
  onVerTablero: () => void;
  onSalir: () => void;
};

export function VictoriaContenido({
  ganador,
  onOtraVez,
  onResumen,
  onVerTablero,
  onSalir,
}: PropsVictoria) {
  const tema = useTema();
  return (
    <Caja>
      <Text style={styles.trofeo}>🏆</Text>
      <View style={styles.fila}>
        <View style={[styles.punto, { backgroundColor: ganador.color }]} />
        <Text style={[styles.ganador, { color: tema.texto }]}>¡{ganador.nombre} gana!</Text>
      </View>
      <Text style={[styles.subtitulo, { color: tema.textoSuave }]}>
        Ha llegado al jardín. ¡Enhorabuena a los dos!
      </Text>
      <Boton texto="Jugar otra vez" onPress={onOtraVez} principal />
      <Boton texto="📋 Ver resumen" onPress={onResumen} />
      <Boton texto="Ver el tablero" onPress={onVerTablero} />
      <Boton texto="Salir al inicio" onPress={onSalir} />
    </Caja>
  );
}

export function FinalContenido({ texto, onContinuar }: { texto: string; onContinuar: () => void }) {
  const tema = useTema();
  return (
    <Caja>
      <Text style={styles.trofeo}>🎉</Text>
      <Text style={[styles.titulo, { color: tema.texto }]}>Pregunta final</Text>
      <Text style={[styles.subtitulo, { color: tema.textoSuave }]}>Para los dos</Text>
      <Text style={[styles.textoFinal, { color: tema.texto }]}>{texto}</Text>
      <Boton texto="Continuar" onPress={onContinuar} principal />
    </Caja>
  );
}

export function ResumenContenido({ resumen, onCerrar }: { resumen: Resumen; onCerrar: () => void }) {
  const tema = useTema();
  return (
    <Caja>
      <Text style={[styles.titulo, { color: tema.texto }]}>Resumen</Text>

      {resumen.porJugador.map((jugador) => (
        <View key={jugador.nombre} style={styles.fila}>
          <View style={[styles.punto, { backgroundColor: jugador.color }]} />
          <Text style={[styles.linea, { color: tema.texto }]}>
            {jugador.nombre}: {jugador.hechas} {jugador.hechas === 1 ? 'hecha' : 'hechas'} ·{' '}
            {jugador.pasadas} {jugador.pasadas === 1 ? 'pasada' : 'pasadas'}
          </Text>
        </View>
      ))}

      {resumen.sintonia ? (
        <Text style={[styles.subtitulo, { color: tema.acento }]}>
          Sintonía: {resumen.sintonia.aciertos} de {resumen.sintonia.total}
        </Text>
      ) : null}

      <Text style={[styles.subtitulo, { color: tema.textoSuave }]}>Lo que habéis compartido</Text>
      {resumen.hechas.length === 0 ? (
        <Text style={[styles.subtitulo, { color: tema.textoSuave }]}>
          Todavía no habéis completado ninguna tarjeta.
        </Text>
      ) : (
        <ScrollView style={styles.lista}>
          {resumen.hechas.map((entrada, i) => (
            <View key={i} style={[styles.item, { borderBottomColor: tema.borde }]}>
              <Text style={[styles.itemTexto, { color: tema.texto }]}>
                {INFO_TIPO[entrada.tarjeta.tipo].icono} {textoTarjeta(entrada.tarjeta)}
              </Text>
              {entrada.respuesta ? (
                <Text style={[styles.itemRespuesta, { color: tema.acento }]}>
                  {entrada.respuesta}
                </Text>
              ) : null}
              <Text style={[styles.itemQuien, { color: tema.textoSuave }]}>
                {resumen.porJugador[entrada.jugador].nombre}
              </Text>
            </View>
          ))}
        </ScrollView>
      )}

      <Boton texto="Cerrar" onPress={onCerrar} principal />
    </Caja>
  );
}

const styles = StyleSheet.create({
  boton: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', width: '100%' },
  botonTexto: { fontSize: 16, fontWeight: '700' },
  trofeo: { fontSize: 52 },
  titulo: { fontSize: 24, fontWeight: '800' },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  punto: { width: 14, height: 14, borderRadius: 7 },
  ganador: { fontSize: 24, fontWeight: '800' },
  subtitulo: { fontSize: 14, textAlign: 'center' },
  textoFinal: { fontSize: 20, fontWeight: '700', textAlign: 'center' },
  linea: { fontSize: 15, fontWeight: '600' },
  lista: { maxHeight: 260, width: '100%' },
  item: { paddingVertical: 8, borderBottomWidth: 1 },
  itemTexto: { fontSize: 14 },
  itemRespuesta: { fontSize: 15, fontWeight: '700', marginTop: 2 },
  itemQuien: { fontSize: 12, marginTop: 2 },
});