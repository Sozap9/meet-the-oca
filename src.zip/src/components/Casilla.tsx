import { StyleSheet, Text, View } from 'react-native';
import type { Casilla as CasillaData } from '../data/board';
import { useTema } from '../temas';
import { COLORES_CASILLA, REDONDEO_CASILLA } from '../theme';
import { IconoCasilla } from './IconosCasilla';

type Props = { casilla: CasillaData; size: number };

export function Casilla({ casilla, size }: Props) {
  const tema = useTema();
  const esNormal = casilla.tipo === 'normal';
  const fondo = esNormal
    ? casilla.numero % 2 === 0
      ? tema.casillaAlterna
      : tema.casilla
    : COLORES_CASILLA[casilla.tipo];
  const alturaFila = size * 0.2;

  return (
    <View
      style={[
        styles.celda,
        {
          width: size,
          height: size,
          borderRadius: size * REDONDEO_CASILLA,
          backgroundColor: fondo,
        },
      ]}
    >
      {esNormal ? (
        <Text style={[styles.numeroGrande, { fontSize: size * 0.42, color: tema.numero }]}>
          {casilla.numero}
        </Text>
      ) : (
        <>
          <View style={[styles.fila, { height: alturaFila }]}>
            <Text style={[styles.numero, { fontSize: size * 0.22 }]}>{casilla.numero}</Text>
          </View>
          <View style={styles.centro}>
            <IconoCasilla tipo={casilla.tipo} size={size * 0.58} />
          </View>
          <View style={[styles.fila, { height: alturaFila }]}>
            {casilla.destino ? (
              <Text style={[styles.destino, { fontSize: size * 0.2 }]}>→ {casilla.destino}</Text>
            ) : null}
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  celda: { alignItems: 'center', justifyContent: 'center' },
  fila: { alignItems: 'center', justifyContent: 'center' },
  centro: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  numeroGrande: { fontWeight: '700' },
  numero: { fontWeight: '700', color: '#555' },
  destino: { fontWeight: '700', color: '#555' },
});