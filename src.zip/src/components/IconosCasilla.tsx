import type { ReactNode } from 'react';
import Svg, { Circle, Ellipse, G, Path, Polygon, Rect, Text as SvgText } from 'react-native-svg';
import type { TipoCasilla } from '../data/board';

function Oca() {
  return (
    <G transform="translate(2.9,3.4) scale(0.468)">
      <Path d="M10 50 L-2 40 L16 44 Z" fill="#ffffff" />
      <Ellipse cx={38} cy={52} rx={28} ry={17} fill="#ffffff" />
      <Path d="M56 46 Q76 42 70 24" fill="none" stroke="#ffffff" strokeWidth={10} strokeLinecap="round" />
      <Circle cx={70} cy={20} r={9} fill="#ffffff" />
      <Path d="M76 17 L92 22 L76 26 Z" fill="#f08a3c" />
      <Circle cx={72} cy={18} r={2} fill="#2b2b2b" />
      <Ellipse cx={34} cy={54} rx={16} ry={9} fill="#dbe7ee" />
      <Path d="M30 68 L30 77 M46 68 L46 77" fill="none" stroke="#f08a3c" strokeWidth={3} strokeLinecap="round" />
    </G>
  );
}

// Verdad o reto: un círculo partido en dos, azul con "?" y rojo con "!"
function VerdadReto() {
  return (
    <>
      <Path d="M24 6 A18 18 0 0 0 24 42 Z" fill="#4a90d9" />
      <Path d="M24 6 A18 18 0 0 1 24 42 Z" fill="#e0546a" />
      <Rect x={23.3} y={6} width={1.4} height={36} fill="#ffffff" />
      <SvgText x={15} y={30} fontSize={18} fontWeight="bold" fill="#ffffff" textAnchor="middle">
        ?
      </SvgText>
      <SvgText x={33} y={30} fontSize={18} fontWeight="bold" fill="#ffffff" textAnchor="middle">
        !
      </SvgText>
    </>
  );
}

function Dados() {
  return (
    <>
      <G transform="rotate(-10 17 22)">
        <Rect x={5} y={10} width={24} height={24} rx={5} fill="#ffffff" stroke="#cbb27a" strokeWidth={1.5} />
        <Circle cx={11} cy={16} r={2.2} fill="#2b2b2b" />
        <Circle cx={23} cy={16} r={2.2} fill="#2b2b2b" />
        <Circle cx={17} cy={22} r={2.2} fill="#2b2b2b" />
        <Circle cx={11} cy={28} r={2.2} fill="#2b2b2b" />
        <Circle cx={23} cy={28} r={2.2} fill="#2b2b2b" />
      </G>
      <G transform="rotate(12 32 30)">
        <Rect x={20} y={18} width={24} height={24} rx={5} fill="#ffffff" stroke="#cbb27a" strokeWidth={1.5} />
        <Circle cx={26} cy={24} r={2.2} fill="#2b2b2b" />
        <Circle cx={32} cy={30} r={2.2} fill="#2b2b2b" />
        <Circle cx={38} cy={36} r={2.2} fill="#2b2b2b" />
      </G>
    </>
  );
}

function Posada() {
  return (
    <>
      <Rect x={32} y={10} width={4} height={10} fill="#a8553e" />
      <Rect x={10} y={22} width={28} height={20} fill="#f4e6c8" />
      <Polygon points="6,24 24,8 42,24" fill="#a8553e" />
      <Rect x={21} y={30} width={7} height={12} rx={1} fill="#7a4a2e" />
      <Rect x={12.5} y={27} width={6} height={6} fill="#f6c453" />
      <Rect x={30} y={27} width={6} height={6} fill="#f6c453" />
    </>
  );
}

function Pozo() {
  return (
    <>
      <Rect x={13} y={14} width={3} height={14} fill="#8d5a3b" />
      <Rect x={32} y={14} width={3} height={14} fill="#8d5a3b" />
      <Polygon points="9,15 24,5 39,15" fill="#a8553e" />
      <Rect x={12} y={27} width={24} height={13} rx={2} fill="#8a8f98" />
      <Ellipse cx={24} cy={27} rx={12} ry={4.5} fill="#6b7079" />
      <Ellipse cx={24} cy={27} rx={9} ry={3} fill="#1f2733" />
      <Path d="M24 15 V21" stroke="#555555" strokeWidth={1.5} />
      <Rect x={21} y={21} width={6} height={5} rx={1} fill="#b98a5a" />
    </>
  );
}

function Laberinto() {
  return (
    <Path
      d="M8 8 H40 V40 H12 V16 H32 V32 H20 V24 H26"
      fill="none"
      stroke="#7a3e2e"
      strokeWidth={3}
      strokeLinejoin="round"
      strokeLinecap="round"
    />
  );
}

function Carcel() {
  return (
    <>
      <Rect x={8} y={8} width={32} height={32} rx={3} fill="#5b6270" />
      <Rect x={12} y={12} width={24} height={24} fill="#2d323c" />
      <Rect x={15} y={12} width={3} height={24} fill="#c9ced6" />
      <Rect x={22.5} y={12} width={3} height={24} fill="#c9ced6" />
      <Rect x={30} y={12} width={3} height={24} fill="#c9ced6" />
    </>
  );
}

function Calavera() {
  return (
    <>
      <Circle cx={24} cy={21} r={13} fill="#f5f2ea" />
      <Rect x={17} y={28} width={14} height={11} rx={3} fill="#f5f2ea" />
      <Circle cx={18} cy={21} r={4} fill="#2b2b2b" />
      <Circle cx={30} cy={21} r={4} fill="#2b2b2b" />
      <Path d="M24 26 L22 30 L26 30 Z" fill="#2b2b2b" />
      <Path d="M20 33 V38 M24 33 V38 M28 33 V38" stroke="#2b2b2b" strokeWidth={1.5} strokeLinecap="round" />
    </>
  );
}

function Jardin() {
  return (
    <>
      <Ellipse cx={24} cy={43} rx={18} ry={4} fill="#6fb36f" />
      <Rect x={12.5} y={8} width={3} height={35} fill="#6b4a2a" />
      <Rect x={17} y={9} width={24} height={18} fill="#ffffff" />
      <Rect x={17} y={9} width={6} height={6} fill="#2b2b2b" />
      <Rect x={29} y={9} width={6} height={6} fill="#2b2b2b" />
      <Rect x={23} y={15} width={6} height={6} fill="#2b2b2b" />
      <Rect x={35} y={15} width={6} height={6} fill="#2b2b2b" />
      <Rect x={17} y={21} width={6} height={6} fill="#2b2b2b" />
      <Rect x={29} y={21} width={6} height={6} fill="#2b2b2b" />
      <Circle cx={34} cy={40} r={2.5} fill="#f28bb0" />
      <Circle cx={40} cy={42} r={2} fill="#ffffff" />
    </>
  );
}

function contenido(tipo: TipoCasilla): ReactNode {
  switch (tipo) {
    case 'oca':
      return <Oca />;
    case 'puente':
      return <VerdadReto />;
    case 'dados':
      return <Dados />;
    case 'posada':
      return <Posada />;
    case 'pozo':
      return <Pozo />;
    case 'laberinto':
      return <Laberinto />;
    case 'carcel':
      return <Carcel />;
    case 'calavera':
      return <Calavera />;
    case 'jardin':
      return <Jardin />;
    default:
      return null;
  }
}

export function IconoCasilla({ tipo, size }: { tipo: TipoCasilla; size: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 48 48">
      {contenido(tipo)}
    </Svg>
  );
}