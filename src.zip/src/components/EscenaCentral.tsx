import Svg, { Circle, Ellipse, G, Path, Rect } from 'react-native-svg';
import type { Modo } from '../data/modos';

type OcaProps = {
  x: number;
  y: number;
  escala?: number;
  cuerpo: string;
  ala: string;
  pico: string;
  sombrero?: boolean;
};

function Oca({ x, y, escala = 1, cuerpo, ala, pico, sombrero = false }: OcaProps) {
  return (
    <G transform={`translate(${x},${y}) scale(${escala})`}>
      <Path d="M10 50 L-2 40 L16 44 Z" fill={cuerpo} />
      <Ellipse cx={38} cy={52} rx={28} ry={17} fill={cuerpo} />
      <Path d="M56 46 Q76 42 70 24" fill="none" stroke={cuerpo} strokeWidth={10} strokeLinecap="round" />
      <Circle cx={70} cy={20} r={9} fill={cuerpo} />
      <Path d="M76 17 L92 22 L76 26 Z" fill={pico} />
      <Circle cx={72} cy={18} r={2} fill="#2b2b2b" />
      <Ellipse cx={34} cy={54} rx={16} ry={9} fill={ala} />
      <Path d="M30 68 L30 77 M46 68 L46 77" fill="none" stroke={pico} strokeWidth={3} strokeLinecap="round" />
      {sombrero ? (
        <>
          <Path d="M62 14 L70 -8 L78 14 Z" fill="#e0546a" />
          <Circle cx={70} cy={-9} r={3.5} fill="#f6c453" />
        </>
      ) : null}
    </G>
  );
}

type PuenteProps = {
  x: number;
  y: number;
  escala?: number;
  madera: string;
  baranda: string;
  farol?: string;
};

function Puente({ x, y, escala = 1, madera, baranda, farol }: PuenteProps) {
  return (
    <G transform={`translate(${x},${y}) scale(${escala})`}>
      <Path d="M4 50 Q40 6 76 50" fill="none" stroke={madera} strokeWidth={9} strokeLinecap="round" />
      <Path d="M4 38 Q40 -6 76 38" fill="none" stroke={baranda} strokeWidth={3} strokeLinecap="round" />
      <Path
        d="M22 22 L22 33 M40 16 L40 28 M58 22 L58 33"
        fill="none"
        stroke={baranda}
        strokeWidth={3}
        strokeLinecap="round"
      />
      {farol ? (
        <>
          <Circle cx={22} cy={17} r={4} fill={farol} />
          <Circle cx={58} cy={17} r={4} fill={farol} />
        </>
      ) : null}
    </G>
  );
}

function Corazon({ x, y, escala = 1, color }: { x: number; y: number; escala?: number; color: string }) {
  return (
    <Path
      d="M0 14 C-22 -6 -8 -24 0 -10 C8 -24 22 -6 0 14 Z"
      transform={`translate(${x},${y}) scale(${escala})`}
      fill={color}
    />
  );
}

function Basico() {
  return (
    <>
      <Rect width={200} height={300} fill="#cfe8f5" />
      <Circle cx={150} cy={50} r={24} fill="#f6c453" />
      <Ellipse cx={50} cy={60} rx={28} ry={9} fill="#ffffff" />
      <Ellipse cx={72} cy={53} rx={18} ry={9} fill="#ffffff" />
      <Ellipse cx={120} cy={110} rx={24} ry={8} fill="#ffffff" />
      <Path d="M0 170 Q60 130 120 165 T200 150 L200 300 L0 300 Z" fill="#8fcf9a" />
      <Rect y={235} width={200} height={65} fill="#79bd88" />
      <Rect y={200} width={200} height={32} fill="#8ec9e8" />
      <Puente x={48} y={161} escala={1.3} madera="#b98a5a" baranda="#9a7048" />
      <Oca x={45} y={212} escala={1.05} cuerpo="#ffffff" ala="#dbe7ee" pico="#f08a3c" />
      <Circle cx={30} cy={272} r={5} fill="#f28bb0" />
      <Circle cx={170} cy={285} r={5} fill="#f6c453" />
      <Circle cx={180} cy={268} r={4} fill="#ffffff" />
      <Circle cx={20} cy={250} r={4} fill="#ffffff" />
    </>
  );
}

function Personal() {
  return (
    <>
      <Rect width={200} height={120} fill="#3b3f78" />
      <Rect y={120} width={200} height={60} fill="#7b6fb5" />
      <Rect y={180} width={200} height={34} fill="#e8a5a0" />
      <Rect y={214} width={200} height={86} fill="#2c3563" />
      <Circle cx={150} cy={56} r={24} fill="#fbe9b7" />
      <Circle cx={160} cy={48} r={20} fill="#3b3f78" />
      <Circle cx={30} cy={30} r={1.5} fill="#fbe9b7" />
      <Circle cx={70} cy={70} r={1.5} fill="#fbe9b7" />
      <Circle cx={100} cy={24} r={1.5} fill="#fbe9b7" />
      <Circle cx={40} cy={110} r={1.5} fill="#fbe9b7" />
      <Circle cx={120} cy={90} r={1.5} fill="#fbe9b7" />
      <Circle cx={175} cy={105} r={1.5} fill="#fbe9b7" />
      <Circle cx={20} cy={70} r={1.5} fill="#fbe9b7" />
      <Path d="M0 205 Q50 175 100 198 T200 190 L200 216 L0 216 Z" fill="#5b4a8a" />
      <Path
        d="M30 235 H100 M90 250 H170 M50 268 H120"
        fill="none"
        stroke="#7b6fb5"
        strokeWidth={2}
        strokeLinecap="round"
      />
      <Puente x={48} y={161} escala={1.3} madera="#8d79c9" baranda="#5b4a8a" farol="#f6c453" />
      <Path d="M0 255 Q70 244 150 258 L150 300 L0 300 Z" fill="#2f3f6b" />
      <Oca x={30} y={212} escala={1.05} cuerpo="#f4efe8" ala="#ddd5e8" pico="#f0a35c" />
    </>
  );
}

function Caliente() {
  return (
    <>
      <Rect width={200} height={300} fill="#5a1630" />
      <Path d="M0 24 Q50 70 100 24 Q150 70 200 24" fill="none" stroke="#8a2a4c" strokeWidth={2} />
      <Circle cx={25} cy={41} r={4.5} fill="#f6c453" />
      <Circle cx={50} cy={47} r={4.5} fill="#f6c453" />
      <Circle cx={75} cy={41} r={4.5} fill="#f6c453" />
      <Circle cx={125} cy={41} r={4.5} fill="#f6c453" />
      <Circle cx={150} cy={47} r={4.5} fill="#f6c453" />
      <Circle cx={175} cy={41} r={4.5} fill="#f6c453" />
      <Rect y={240} width={200} height={60} fill="#3f0f23" />
      <Corazon x={100} y={120} escala={2.6} color="#e0546a" />
      <Puente x={48} y={175} escala={1.3} madera="#c0405e" baranda="#8a2a4c" farol="#f6c453" />
      <Oca x={45} y={214} cuerpo="#fbe3dc" ala="#f1b9b0" pico="#f6c453" />
      <Corazon x={150} y={240} escala={0.7} color="#e0546a" />
    </>
  );
}

function Aleatorio() {
  return (
    <>
      <Rect width={200} height={300} fill="#efe6cf" />
      <Rect y={250} width={200} height={50} fill="#e2d6b8" />
      <Circle cx={30} cy={40} r={6} fill="#4f9d69" />
      <Circle cx={90} cy={26} r={5} fill="#e0546a" />
      <Circle cx={160} cy={60} r={6} fill="#7b6fb5" />
      <Circle cx={180} cy={24} r={5} fill="#f6c453" />
      <Circle cx={40} cy={110} r={5} fill="#e0546a" />
      <Circle cx={170} cy={130} r={5} fill="#4f9d69" />
      <Circle cx={20} cy={170} r={5} fill="#7b6fb5" />
      <Circle cx={185} cy={190} r={4} fill="#e0546a" />
      <Rect x={110} y={70} width={9} height={9} fill="#f6c453" transform="rotate(20 114 74)" />
      <Rect x={60} y={150} width={9} height={9} fill="#7b6fb5" transform="rotate(-15 64 154)" />
      <Rect x={150} y={170} width={10} height={10} fill="#e0546a" transform="rotate(30 155 175)" />
      <Path d="M130 40 L138 54 L122 54 Z" fill="#4f9d69" />
      <Path d="M70 85 L78 99 L62 99 Z" fill="#e0546a" />
      <G transform="translate(52,100) rotate(-12 42 42) scale(1.5)">
        <Rect width={56} height={56} rx={10} fill="#ffffff" stroke="#d2c7aa" strokeWidth={2} />
        <Circle cx={14} cy={14} r={4.5} fill="#2b2b2b" />
        <Circle cx={42} cy={14} r={4.5} fill="#2b2b2b" />
        <Circle cx={28} cy={28} r={4.5} fill="#2b2b2b" />
        <Circle cx={14} cy={42} r={4.5} fill="#2b2b2b" />
        <Circle cx={42} cy={42} r={4.5} fill="#2b2b2b" />
      </G>
      <Oca x={45} y={214} cuerpo="#ffffff" ala="#e4ddd0" pico="#f08a3c" sombrero />
    </>
  );
}

export function EscenaCentral({ modo }: { modo: Modo }) {
  return (
    <Svg width="100%" height="100%" viewBox="0 0 200 300" preserveAspectRatio="xMidYMid slice">
      {modo === 'basico' ? (
        <Basico />
      ) : modo === 'personal' ? (
        <Personal />
      ) : modo === 'caliente' ? (
        <Caliente />
      ) : (
        <Aleatorio />
      )}
    </Svg>
  );
}