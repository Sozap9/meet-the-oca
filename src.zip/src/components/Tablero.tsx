import type { ReactNode } from 'react';
import { useEffect, useRef, useState } from 'react';
import { StyleSheet, View, useWindowDimensions } from 'react-native';
import { TABLERO, TOTAL_CASILLAS } from '../data/board';
import { AREA_CENTRAL, COLUMNAS, FILAS, POSICIONES } from '../data/espiral';
import type { Modo } from '../data/modos';
import type { Jugador } from '../engine/juego';
import type { Paso } from '../engine/recorrido';
import { useTema } from '../temas';
import { Casilla } from './Casilla';
import { CasillaSalida } from './CasillaSalida';
import { DadoAnimado } from './Dado';
import type { TiradaEnCurso } from './Dado';
import { EscenaCentral } from './EscenaCentral';
import { DURACION_PASO, DURACION_SALTO, FichaAnimada } from './FichaAnimada';

// Proporciones respecto al hueco de cada casilla (1 = hueco completo)
const RATIO_CASILLA = 0.88; // tamaño de la casilla
const GROSOR_PISTA = 0.98; // grosor de la cinta que las une
const RATIO_DADO = 1.4; // lado del dado

// Altura que ocupan cabecera, barra del modo, panel de turno y márgenes
const ALTURA_RESERVADA = 350;

// Esquina de la casilla donde se dibuja la ficha de cada jugador
const ESQUINAS = [
  { arriba: true, izquierda: true },
  { arriba: false, izquierda: false },
  { arriba: true, izquierda: false },
  { arriba: false, izquierda: true },
];

// El recorrido que tiene que hacer una ficha tras una tirada
export interface AnimacionFicha {
  id: number;
  jugador: number;
  pasos: Paso[];
}

type Props = {
  modo: Modo;
  jugadores: Jugador[];
  tirada: TiradaEnCurso | null;
  onTiradaTerminada: () => void;
  animacion: AnimacionFicha | null;
  onAnimacionTerminada: () => void;
  turnoActivo: number | null; // a quién le toca jugar (late un aro en su ficha)
  aviso?: ReactNode; // cartel que se dibuja en el centro del tablero
};

export function Tablero({
  modo,
  jugadores,
  tirada,
  onTiradaTerminada,
  animacion,
  onAnimacionTerminada,
  turnoActivo,
  aviso,
}: Props) {
  const tema = useTema();
  const { width, height } = useWindowDimensions();
  const porAncho = (width - 16) / COLUMNAS;
  const porAlto = (height - ALTURA_RESERVADA) / FILAS;
  const hueco = Math.floor(Math.min(porAncho, porAlto));

  const tamCasilla = hueco * RATIO_CASILLA;
  const grosor = hueco * GROSOR_PISTA;
  const inset = hueco * 0.1;
  const tamFicha = tamCasilla * 0.34;
  const margenFicha = tamCasilla * 0.08;
  const tamDado = hueco * RATIO_DADO;

  // Casilla en la que se está dibujando cada ficha, y cómo llegó hasta ella
  const [visuales, setVisuales] = useState(() => jugadores.map((j) => j.posicion));
  const [llegada, setLlegada] = useState<('paso' | 'salto')[]>(() => jugadores.map(() => 'paso'));
  const alTerminar = useRef(onAnimacionTerminada);
  alTerminar.current = onAnimacionTerminada;

  // Si algo mueve las fichas sin recorrido (reiniciar, retroceder...), saltan a su sitio
  useEffect(() => {
    if (animacion) return;
    if (jugadores.some((j, i) => j.posicion !== visuales[i])) {
      setLlegada(jugadores.map(() => 'salto'));
      setVisuales(jugadores.map((j) => j.posicion));
    }
  }, [jugadores, animacion, visuales]);

  // Recorre la ruta paso a paso y avisa cuando la ficha ha llegado
  useEffect(() => {
    if (!animacion) return;
    let cancelado = false;
    const temporizadores: ReturnType<typeof setTimeout>[] = [];
    let espera = 0;

    animacion.pasos.forEach((paso) => {
      temporizadores.push(
        setTimeout(() => {
          if (cancelado) return;
          setLlegada((l) => l.map((t, k) => (k === animacion.jugador ? paso.tipo : t)));
          setVisuales((v) => v.map((p, k) => (k === animacion.jugador ? paso.posicion : p)));
        }, espera),
      );
      espera += paso.tipo === 'salto' ? DURACION_SALTO : DURACION_PASO;
    });
    temporizadores.push(
      setTimeout(() => {
        if (!cancelado) alTerminar.current();
      }, espera + 120),
    );

    return () => {
      cancelado = true;
      temporizadores.forEach(clearTimeout);
    };
  }, [animacion?.id]);

  // Esquina superior izquierda de una casilla (la 0 es la salida)
  const origen = (numero: number) => {
    const { fila, columna } = POSICIONES[numero];
    return {
      x: columna * hueco + (hueco - tamCasilla) / 2,
      y: fila * hueco + (hueco - tamCasilla) / 2,
    };
  };

  // Centro de cada casilla en píxeles
  const centro = (numero: number) => {
    const { fila, columna } = POSICIONES[numero];
    return { x: columna * hueco + hueco / 2, y: fila * hueco + hueco / 2 };
  };

  return (
    <View
      style={{
        width: hueco * COLUMNAS,
        height: hueco * FILAS,
        backgroundColor: tema.fondoTablero,
        borderRadius: grosor / 2,
      }}
    >
      {/* Imagen central: una escena distinta por modo */}
      <View
        style={[
          styles.centro,
          {
            left: AREA_CENTRAL.columna * hueco + inset,
            top: AREA_CENTRAL.fila * hueco + inset,
            width: AREA_CENTRAL.columnas * hueco - inset * 2,
            height: AREA_CENTRAL.filas * hueco - inset * 2,
            backgroundColor: tema.centro,
            borderColor: tema.centroBorde,
          },
        ]}
      >
        <EscenaCentral modo={modo} />
      </View>

      {/* Pista: una cinta redondeada entre cada casilla y la siguiente, desde la salida */}
      {Array.from({ length: TOTAL_CASILLAS }, (_, i) => {
        const a = centro(i);
        const b = centro(i + 1);
        return (
          <View
            key={`pista-${i}`}
            style={{
              position: 'absolute',
              left: Math.min(a.x, b.x) - grosor / 2,
              top: Math.min(a.y, b.y) - grosor / 2,
              width: Math.abs(a.x - b.x) + grosor,
              height: Math.abs(a.y - b.y) + grosor,
              borderRadius: grosor / 2,
              backgroundColor: tema.pista,
            }}
          />
        );
      })}

      {/* Salida (casilla 0) */}
      <View style={{ position: 'absolute', left: origen(0).x, top: origen(0).y }}>
        <CasillaSalida size={tamCasilla} />
      </View>

      {/* Casillas */}
      {TABLERO.map((casilla) => (
        <View
          key={casilla.numero}
          style={{
            position: 'absolute',
            left: origen(casilla.numero).x,
            top: origen(casilla.numero).y,
          }}
        >
          <Casilla casilla={casilla} size={tamCasilla} />
        </View>
      ))}

      {/* Fichas */}
      {jugadores.map((jugador, i) => {
        const esquina = ESQUINAS[i % ESQUINAS.length];
        const { x, y } = origen(visuales[i] ?? jugador.posicion);
        return (
          <FichaAnimada
            key={jugador.id}
            color={jugador.color}
            size={tamFicha}
            x={x + (esquina.izquierda ? margenFicha : tamCasilla - tamFicha - margenFicha)}
            y={y + (esquina.arriba ? margenFicha : tamCasilla - tamFicha - margenFicha)}
            tipo={llegada[i] ?? 'paso'}
            activa={turnoActivo === i}
          />
        );
      })}

      {/* Dado: entra y gira sobre el hueco central */}
      {tirada ? (
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: (AREA_CENTRAL.columna + AREA_CENTRAL.columnas / 2) * hueco - tamDado / 2,
            top: (AREA_CENTRAL.fila + AREA_CENTRAL.filas / 2) * hueco - tamDado / 2,
          }}
        >
          <DadoAnimado
            key={tirada.id}
            valor={tirada.valor}
            size={tamDado}
            onTerminar={onTiradaTerminada}
          />
        </View>
      ) : null}

      {/* Cartel de turno: centrado sobre la imagen, por encima de todo */}
      {aviso ? (
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: AREA_CENTRAL.columna * hueco + inset,
            top: AREA_CENTRAL.fila * hueco + inset,
            width: AREA_CENTRAL.columnas * hueco - inset * 2,
            height: AREA_CENTRAL.filas * hueco - inset * 2,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {aviso}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  centro: {
    position: 'absolute',
    borderWidth: 2,
    borderRadius: 14,
    overflow: 'hidden',
  },
});