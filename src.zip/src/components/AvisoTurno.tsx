import { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text } from 'react-native';

type Props = {
  texto: string;
  subtexto?: string;
  color: string;
  onTerminar: () => void;
};

// Devuelve true si el color es claro y necesita texto oscuro
function esClaro(hex: string): boolean {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.6;
}

export function AvisoTurno({ texto, subtexto, color, onTerminar }: Props) {
  const progreso = useRef(new Animated.Value(0)).current;
  const alTerminar = useRef(onTerminar);
  alTerminar.current = onTerminar;

  // Entra con un pequeño rebote, se queda un momento y se va
  useEffect(() => {
    const animacion = Animated.sequence([
      Animated.timing(progreso, {
        toValue: 1,
        duration: 320,
        easing: Easing.out(Easing.back(1.8)),
        useNativeDriver: true,
      }),
      Animated.delay(1100),
      Animated.timing(progreso, {
        toValue: 2,
        duration: 260,
        easing: Easing.in(Easing.quad),
        useNativeDriver: true,
      }),
    ]);
    animacion.start(({ finished }) => {
      if (finished) alTerminar.current();
    });
    return () => animacion.stop();
  }, [progreso]);

  const textoColor = esClaro(color) ? '#222222' : '#ffffff';

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.tarjeta,
        {
          backgroundColor: color,
          opacity: progreso.interpolate({ inputRange: [0, 0.5, 1, 2], outputRange: [0, 1, 1, 0] }),
          transform: [
            { scale: progreso.interpolate({ inputRange: [0, 1, 2], outputRange: [0.6, 1, 0.9] }) },
          ],
        },
      ]}
    >
      <Text style={[styles.texto, { color: textoColor }]}>{texto}</Text>
      {subtexto ? <Text style={[styles.subtexto, { color: textoColor }]}>{subtexto}</Text> : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  tarjeta: {
    maxWidth: '100%',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 20,
    shadowColor: '#000000',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  texto: { fontSize: 19, fontWeight: '800', textAlign: 'center' },
  subtexto: { fontSize: 14, fontWeight: '700', marginTop: 4, opacity: 0.9 },
});