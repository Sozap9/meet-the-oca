import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { resolverRonda } from '../engine/interacciones';
import type { OpcionRonda, TipoRonda } from '../engine/interacciones';
import type { Jugador } from '../engine/juego';
import { useTema } from '../temas';

// ---------- Escala ----------

type PropsEscala = {
  min: number;
  max: number;
  valor: number | null;
  onCambio: (valor: number) => void;
  etiquetas?: [string, string];
};

export function SelectorEscala({ min, max, valor, onCambio, etiquetas }: PropsEscala) {
  const tema = useTema();
  const numeros = Array.from({ length: max - min + 1 }, (_, i) => min + i);

  return (
    <View style={styles.bloque}>
      <View style={styles.numeros}>
        {numeros.map((n) => {
          const activo = valor === n;
          return (
            <Pressable
              key={n}
              onPress={() => onCambio(n)}
              style={[
                styles.numero,
                {
                  backgroundColor: activo ? tema.acento : '#ffffff',
                  borderColor: activo ? tema.acento : tema.borde,
                },
              ]}
            >
              <Text style={[styles.numeroTexto, { color: activo ? tema.acentoTexto : tema.texto }]}>
                {n}
              </Text>
            </Pressable>
          );
        })}
      </View>
      {etiquetas ? (
        <View style={styles.extremos}>
          <Text style={[styles.extremo, { color: tema.textoSuave }]}>{etiquetas[0]}</Text>
          <Text style={[styles.extremo, { color: tema.textoSuave }]}>{etiquetas[1]}</Text>
        </View>
      ) : null}
    </View>
  );
}

// ---------- Temporizador ----------

export function Temporizador({ segundos }: { segundos: number }) {
  const tema = useTema();
  const [restante, setRestante] = useState(segundos);
  const [activo, setActivo] = useState(false);

  useEffect(() => {
    if (!activo) return;
    const intervalo = setInterval(() => setRestante((r) => Math.max(r - 1, 0)), 1000);
    return () => clearInterval(intervalo);
  }, [activo]);

  const terminado = restante === 0;
  useEffect(() => {
    if (terminado) setActivo(false);
  }, [terminado]);

  const minutos = Math.floor(restante / 60);
  const resto = restante % 60;
  const reloj = `${String(minutos).padStart(2, '0')}:${String(resto).padStart(2, '0')}`;

  const pulsar = () => {
    if (terminado) {
      setRestante(segundos);
      setActivo(false);
    } else {
      setActivo((a) => !a);
    }
  };

  return (
    <View style={styles.bloque}>
      <Text style={[styles.reloj, { color: terminado ? tema.acento : tema.texto }]}>
        {terminado ? '¡Tiempo!' : reloj}
      </Text>
      <Pressable style={[styles.botonSecundario, { backgroundColor: tema.casillaAlterna }]} onPress={pulsar}>
        <Text style={[styles.botonSecundarioTexto, { color: tema.texto }]}>
          {terminado ? 'Repetir' : activo ? 'Pausa' : 'Empezar'}
        </Text>
      </Pressable>
    </View>
  );
}

// ---------- Rondas de dos personas ----------

function ListaOpciones({
  opciones,
  valor,
  onElegir,
}: {
  opciones: OpcionRonda[];
  valor: string | null;
  onElegir: (id: string) => void;
}) {
  const tema = useTema();
  const compacta = opciones.length > 5;

  return (
    <View style={compacta ? styles.rejilla : styles.columna}>
      {opciones.map((opcion) => {
        const activa = valor === opcion.id;
        return (
          <Pressable
            key={opcion.id}
            onPress={() => onElegir(opcion.id)}
            style={[
              compacta ? styles.opcionCompacta : styles.opcion,
              {
                backgroundColor: activa ? tema.opcionActiva : '#ffffff',
                borderColor: activa ? tema.acento : tema.borde,
              },
            ]}
          >
            {opcion.color ? <View style={[styles.muestra, { backgroundColor: opcion.color }]} /> : null}
            <Text style={[styles.opcionTexto, { color: tema.texto }]}>{opcion.etiqueta}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

type PropsRonda = {
  tipo: TipoRonda;
  opciones: OpcionRonda[];
  primero: Jugador; // quien recibe la tarjeta y responde primero
  segundo: Jugador;
  pases: number;
  onPasar: () => void;
  onTerminar: (respuesta: string, acierto?: boolean) => void;
};

export function RondaDoble({ tipo, opciones, primero, segundo, pases, onPasar, onTerminar }: PropsRonda) {
  const tema = useTema();
  const [fase, setFase] = useState<'a' | 'pasar' | 'b' | 'revelar'>('a');
  const [eleccionA, setEleccionA] = useState<string | null>(null);
  const [eleccionB, setEleccionB] = useState<string | null>(null);

  const consigna =
    tipo === 'adivinar' ? 'Responde en secreto' : tipo === 'semaforo' ? '¿Cómo lo ves?' : '¿Estás de acuerdo?';
  const consignaSegundo = tipo === 'adivinar' ? 'Intenta adivinar su respuesta' : consigna;
  const etiqueta = (id: string | null) => opciones.find((o) => o.id === id)?.etiqueta ?? '';
  const colorDe = (id: string | null) => opciones.find((o) => o.id === id)?.color;
  const sinPases = pases <= 0;

  const resultado =
    eleccionA !== null && eleccionB !== null ? resolverRonda(tipo, eleccionA, eleccionB) : null;

  const terminar = () => {
    const respuesta =
      tipo === 'adivinar'
        ? `${primero.nombre}: ${etiqueta(eleccionA)} · ${segundo.nombre} adivinó: ${etiqueta(eleccionB)}`
        : `${primero.nombre}: ${etiqueta(eleccionA)} · ${segundo.nombre}: ${etiqueta(eleccionB)}`;
    onTerminar(respuesta, resultado?.acierto);
  };

  if (fase === 'a') {
    return (
      <View style={styles.bloque}>
        <Text style={[styles.consigna, { color: tema.texto }]}>
          {primero.nombre}: {consigna}
        </Text>
        <Text style={[styles.ayuda, { color: tema.textoSuave }]}>Que no lo vea {segundo.nombre}</Text>
        <ListaOpciones opciones={opciones} valor={eleccionA} onElegir={setEleccionA} />
        <View style={styles.botones}>
          <Pressable
            style={[styles.boton, { backgroundColor: tema.casillaAlterna }, sinPases && styles.inactivo]}
            onPress={onPasar}
            disabled={sinPases}
          >
            <Text style={[styles.botonTexto, { color: tema.texto }]}>
              {sinPases ? 'Sin pases' : `Pasar (${pases})`}
            </Text>
          </Pressable>
          <Pressable
            style={[styles.boton, { backgroundColor: tema.acento }, eleccionA === null && styles.inactivo]}
            onPress={() => setFase('pasar')}
            disabled={eleccionA === null}
          >
            <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Confirmar</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  if (fase === 'pasar') {
    return (
      <View style={styles.bloque}>
        <Text style={styles.telefono}>📱</Text>
        <Text style={[styles.consigna, { color: tema.texto }]}>
          Pasa el móvil a {segundo.nombre}
        </Text>
        <Text style={[styles.ayuda, { color: tema.textoSuave }]}>
          La respuesta de {primero.nombre} queda oculta
        </Text>
        <Pressable style={[styles.boton, { backgroundColor: tema.acento }]} onPress={() => setFase('b')}>
          <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Soy {segundo.nombre}</Text>
        </Pressable>
      </View>
    );
  }

  if (fase === 'b') {
    return (
      <View style={styles.bloque}>
        <Text style={[styles.consigna, { color: tema.texto }]}>
          {segundo.nombre}: {consignaSegundo}
        </Text>
        <ListaOpciones opciones={opciones} valor={eleccionB} onElegir={setEleccionB} />
        <Pressable
          style={[styles.boton, { backgroundColor: tema.acento }, eleccionB === null && styles.inactivo]}
          onPress={() => setFase('revelar')}
          disabled={eleccionB === null}
        >
          <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Confirmar</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.bloque}>
      <View style={styles.revelacion}>
        {[
          { jugador: primero, id: eleccionA, verbo: '' },
          { jugador: segundo, id: eleccionB, verbo: tipo === 'adivinar' ? 'adivinó ' : '' },
        ].map(({ jugador, id, verbo }) => (
          <View key={jugador.id} style={styles.fila}>
            <View style={[styles.punto, { backgroundColor: jugador.color }]} />
            <Text style={[styles.respuesta, { color: tema.texto }]}>
              {jugador.nombre} {verbo}→ {etiqueta(id)}
            </Text>
            {colorDe(id) ? <View style={[styles.muestra, { backgroundColor: colorDe(id) }]} /> : null}
          </View>
        ))}
      </View>
      {resultado ? (
        <Text style={[styles.mensaje, { color: tema.acento }]}>{resultado.mensaje}</Text>
      ) : null}
      <Pressable style={[styles.boton, { backgroundColor: tema.acento }]} onPress={terminar}>
        <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>Listo</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  bloque: { width: '100%', alignItems: 'center', gap: 12 },
  numeros: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8 },
  numero: {
    width: 46,
    height: 46,
    borderRadius: 23,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  numeroTexto: { fontSize: 18, fontWeight: '800' },
  extremos: { width: '100%', flexDirection: 'row', justifyContent: 'space-between' },
  extremo: { fontSize: 13, fontWeight: '600' },
  reloj: { fontSize: 56, fontWeight: '800' },
  botonSecundario: { paddingVertical: 12, paddingHorizontal: 28, borderRadius: 14 },
  botonSecundarioTexto: { fontSize: 16, fontWeight: '700' },
  columna: { width: '100%', gap: 10 },
  rejilla: { width: '100%', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8 },
  opcion: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    borderWidth: 2,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 12,
  },
  opcionCompacta: {
    minWidth: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  opcionTexto: { fontSize: 18, fontWeight: '700', textAlign: 'center' },
  muestra: { width: 18, height: 18, borderRadius: 9 },
  consigna: { fontSize: 20, fontWeight: '800', textAlign: 'center' },
  ayuda: { fontSize: 13, textAlign: 'center' },
  telefono: { fontSize: 56 },
  botones: { flexDirection: 'row', gap: 12 },
  boton: { paddingVertical: 14, paddingHorizontal: 26, borderRadius: 14, minWidth: 120, alignItems: 'center' },
  botonTexto: { fontSize: 16, fontWeight: '700' },
  inactivo: { opacity: 0.4 },
  revelacion: { width: '100%', gap: 10 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  punto: { width: 14, height: 14, borderRadius: 7 },
  respuesta: { flexShrink: 1, fontSize: 17, fontWeight: '700' },
  mensaje: { fontSize: 17, fontWeight: '700', textAlign: 'center' },
});