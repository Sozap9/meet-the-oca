import { Link } from 'expo-router';
import { Pressable, StyleSheet, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function Inicio() {
  return (
    <SafeAreaView style={styles.contenedor}>
      <Text style={styles.titulo}>Meet the Oca</Text>
      <Text style={styles.subtitulo}>Descubre a tu pareja jugando a la oca</Text>
      <Link href="/modos" asChild>
        <Pressable style={styles.boton}>
          <Text style={styles.botonTexto}>Jugar</Text>
        </Pressable>
      </Link>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  contenedor: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16, padding: 24 },
  titulo: { fontSize: 36, fontWeight: '800' },
  subtitulo: { fontSize: 16, color: '#666', textAlign: 'center' },
  boton: { marginTop: 24, backgroundColor: '#2f7d4f', paddingVertical: 14, paddingHorizontal: 48, borderRadius: 12 },
  botonTexto: { color: '#fff', fontSize: 18, fontWeight: '700' },
});