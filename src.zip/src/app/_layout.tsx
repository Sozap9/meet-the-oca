import { Stack } from 'expo-router';

const FONDO = '#f2f2f2';
const TEXTO = '#222222';

export default function RootLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: FONDO },
        headerShadowVisible: false,
        headerTintColor: TEXTO,
        headerTitleStyle: { color: TEXTO },
        contentStyle: { backgroundColor: FONDO },
      }}
    >
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="modos" options={{ title: 'Elige un modo' }} />
      <Stack.Screen name="jugadores" options={{ title: 'Jugadores' }} />
      <Stack.Screen name="juego" options={{ title: 'Partida' }} />
      <Stack.Screen name="dado" options={{ title: 'Dado de temas' }} />
      <Stack.Screen name="reglas" options={{ title: 'Reglas', presentation: 'modal' }} />
    </Stack>
  );
}