import { ScrollView, StyleSheet, Text, View } from 'react-native';

const SECCIONES: { titulo: string; lineas: string[] }[] = [
  {
    titulo: 'Objetivo',
    lineas: [
      'En los modos con tablero, llegar el primero a la casilla 63, el jardín, con la tirada exacta. Si te pasas, rebotas hacia atrás.',
      'Al llegar al jardín os espera una última pregunta para los dos.',
      'Por el camino, cada casilla es una excusa para conoceros mejor.',
    ],
  },
  {
    titulo: 'Cada turno',
    lineas: [
      'Tira el dado y avanza. Al caer en una casilla normal sale una tarjeta para ti: una pregunta, un reto, un "¿qué prefieres?"...',
      'A medida que avanza la partida, las tarjetas se vuelven más profundas.',
      'Cada persona tiene 3 pases para saltarse tarjetas. La carta comodín regala uno extra.',
    ],
  },
  {
    titulo: 'Casillas especiales',
    lineas: [
      '🪿 Oca: contestas una pregunta ligera y vuelves a tirar.',
      '❓❗ Verdad o reto (6 y 12): eliges verdad o reto para la otra persona.',
      '🎲 Dados (26 y 53): eliges entre un duelo (los dos tiráis y quien saque menos contesta una pregunta íntima) o una apuesta (quien saque menos retrocede 10 casillas y contesta una pregunta ligera).',
      '🛏️ Posada (19): pagas contestando una pregunta de intensidad media, o pierdes un turno.',
      '⛓️ Cárcel (52): cumples dos turnos o pagas la fianza con una pregunta profunda o con un reto que elige la otra persona.',
      '🕳️ Pozo (31): quedas atrapado hasta que la otra persona te pase, o tres turnos si ya va por delante. Cada turno que se salta, te hace una pregunta desde arriba, y puede sacarte al instante con la cuerda si contesta una pregunta íntima. Si cae justo en el pozo, te rescata.',
      '🌀 Laberinto (42): retrocedes a la 30.',
      '💀 Calavera (58): vuelves a la 1.',
    ],
  },
  {
    titulo: 'Tipos de tarjeta',
    lineas: [
      '🤔 Elegir y ✍️ escribir: respondes en la propia tarjeta. Lo escrito se puede compartir en el resumen.',
      '🔮 Adivinar: una persona responde en secreto, pasa el móvil y la otra intenta acertar.',
      '🚦 Semáforo: cada uno marca verde, amarillo o rojo sin ver al otro. Un rojo siempre se respeta.',
      '⚖️ Debate: cada uno vota y luego se revela.',
      '🎯 Retos con cuenta atrás y escalas del 1 al 10.',
    ],
  },
  {
    titulo: 'Modos',
    lineas: [
      '🌱 Básico: gustos y curiosidades para empezar.',
      '💬 Personal: recuerdos, valores, sueños y miedos.',
      '🔥 Caliente: atracción, coqueteo, citas y retos de cercanía.',
      '🎲 Aleatorio: una mezcla de los niveles que elijáis.',
      '🧩 Dado de temas: sin tablero; el dado elige el tema (ligeras, futuro, reflexiones, confesiones, íntimo o retos) y salta una tarjeta.',
    ],
  },
];

export default function Reglas() {
  return (
    <ScrollView contentContainerStyle={styles.contenido} contentInsetAdjustmentBehavior="automatic">
      {SECCIONES.map((seccion) => (
        <View key={seccion.titulo} style={styles.seccion}>
          <Text style={styles.titulo}>{seccion.titulo}</Text>
          {seccion.lineas.map((linea, i) => (
            <Text key={i} style={styles.linea}>
              {linea}
            </Text>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20, gap: 20 },
  seccion: { gap: 8 },
  titulo: { fontSize: 20, fontWeight: '800' },
  linea: { fontSize: 15, color: '#444', lineHeight: 22 },
});