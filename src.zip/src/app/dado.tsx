import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import type { ReactNode } from 'react';
import { useRef, useState } from 'react';
import {
  Alert,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Capa } from '../components/Capa';
import { DadoAnimado, DadoReposo } from '../components/Dado';
import type { CaraVisual } from '../components/Dado';
import { TarjetaContenido } from '../components/ModalesJuego';
import { FinDadoContenido } from '../components/ModalesDado';
import { FinalContenido, MenuContenido, ResumenContenido } from '../components/ModalesPartida';
import { CATEGORIAS_DADO, leerRondas } from '../data/dadoTemas';
import type { CategoriaDado } from '../data/dadoTemas';
import { tarjetasDeModo } from '../data/decks';
import { finalDeModo } from '../data/finales';
import type { Tarjeta } from '../data/tarjetas';
import { crearJuego, tirarDado } from '../engine/juego';
import { crearBaraja, intensidadSegunRonda } from '../engine/mazos';
import { leerParticipantes } from '../engine/participantes';
import { crearPases, darPase, gastarPase } from '../engine/pases';
import { resumir } from '../engine/resumen';
import type { Entrada } from '../engine/resumen';
import { TEMAS, TemaProvider } from '../temas';
import { COLORES_JUGADOR } from '../theme';

const ESPERA_CIERRE_MS = 400;

// Las caras del dado son las categorías
const CARAS_CATEGORIAS: CaraVisual[] = CATEGORIAS_DADO.map((c) => ({
  fondo: c.color,
  icono: c.icono,
}));

type TarjetaActiva = { id: number; tarjeta: Tarjeta; categoria: CategoriaDado };
type Reposo = { valor: number; inclinacion: number };

// Confirmación que funciona en el móvil y en la vista web
function confirmar(titulo: string, mensaje: string, textoOk: string, alAceptar: () => void) {
  if (Platform.OS === 'web') {
    if (window.confirm(`${titulo}\n${mensaje}`)) alAceptar();
    return;
  }
  Alert.alert(titulo, mensaje, [
    { text: 'Cancelar', style: 'cancel' },
    { text: textoOk, style: 'destructive', onPress: alAceptar },
  ]);
}

export default function Dado() {
  const router = useRouter();
  const { jugadores: jugadoresParam, rondas: rondasParam } = useLocalSearchParams<{
    jugadores?: string;
    rondas?: string;
  }>();
  const participantes = leerParticipantes(jugadoresParam, COLORES_JUGADOR);
  const total = leerRondas(rondasParam);
  const tema = TEMAS.dado;
  const { width } = useWindowDimensions();
  const mesa = Math.min(width - 48, 340);
  const tamDado = mesa * 0.44;

  const nuevaBaraja = () => crearBaraja(tarjetasDeModo('dado'));

  const [jugadores] = useState(() => crearJuego(participantes).jugadores);
  const [baraja, setBaraja] = useState(nuevaBaraja);
  const [pases, setPases] = useState(() => crearPases(participantes.length));
  const [historial, setHistorial] = useState<Entrada[]>([]);
  const [ronda, setRonda] = useState(0); // tiradas ya completadas
  const [turno, setTurno] = useState(0);
  const [tirada, setTirada] = useState<{ id: number; valor: number; inclinacion: number } | null>(null);
  const [reposo, setReposo] = useState<Reposo>({ valor: 6, inclinacion: 0.15 });
  const [categoriaActual, setCategoriaActual] = useState<CategoriaDado | null>(null);
  const [tarjeta, setTarjeta] = useState<TarjetaActiva | null>(null);
  const [final, setFinal] = useState<string | null>(null);
  const [fin, setFin] = useState(false);
  const [menuAbierto, setMenuAbierto] = useState(false);
  const [resumenAbierto, setResumenAbierto] = useState(false);
  const siguienteId = useRef(0);

  const tirar = () => {
    if (tirada || tarjeta || final !== null || fin) return;
    siguienteId.current += 1;
    setCategoriaActual(null);
    setTirada({
      id: siguienteId.current,
      valor: tirarDado(),
      inclinacion: (Math.random() - 0.5) * 0.4,
    });
  };

  const terminarTirada = () => {
    if (!tirada) return;
    const categoria = CATEGORIAS_DADO[tirada.valor - 1];
    setReposo({ valor: tirada.valor, inclinacion: tirada.inclinacion });
    setTirada(null);
    setCategoriaActual(categoria);

    const nueva = baraja.robar(undefined, intensidadSegunRonda(ronda, total), categoria.categoria);
    if (nueva) {
      siguienteId.current += 1;
      setTarjeta({ id: siguienteId.current, tarjeta: nueva, categoria });
    } else {
      avanzar();
    }
  };

  // Termina la tirada: pregunta final si era la última, o turno de la otra persona
  const avanzar = () => {
    const completadas = ronda + 1;
    setRonda(completadas);
    if (completadas >= total) setFinal(finalDeModo('dado'));
    else setTurno((t) => (t + 1) % jugadores.length);
  };

  const resolverTarjeta = (resultado: 'hecha' | 'pasada', respuesta?: string, acierto?: boolean) => {
    if (!tarjeta) return;
    const { tarjeta: actual } = tarjeta;
    setHistorial((h) => [...h, { jugador: turno, tarjeta: actual, resultado, respuesta, acierto }]);
    if (resultado === 'pasada') setPases((p) => gastarPase(p, turno));
    else if (actual.tipo === 'comodin') setPases((p) => darPase(p, turno));
    setTarjeta(null);
    avanzar();
  };

  const reiniciar = () => {
    setTirada(null);
    setTarjeta(null);
    setFinal(null);
    setFin(false);
    setMenuAbierto(false);
    setResumenAbierto(false);
    setCategoriaActual(null);
    setHistorial([]);
    setPases(crearPases(participantes.length));
    setRonda(0);
    setTurno(0);
    setBaraja(nuevaBaraja());
  };

  const salir = () => router.dismissAll();

  const abrirReglas = () => {
    setMenuAbierto(false);
    setTimeout(() => router.push('/reglas'), ESPERA_CIERRE_MS);
  };

  const abrirResumen = () => {
    setMenuAbierto(false);
    setResumenAbierto(true);
  };

  const pedirReinicio = () => {
    setMenuAbierto(false);
    setTimeout(
      () => confirmar('¿Reiniciar la partida?', 'Se perderá el progreso actual.', 'Reiniciar', reiniciar),
      ESPERA_CIERRE_MS,
    );
  };

  const pedirSalida = () => {
    setMenuAbierto(false);
    setTimeout(
      () => confirmar('¿Salir de la partida?', 'Se perderá el progreso actual.', 'Salir', salir),
      ESPERA_CIERRE_MS,
    );
  };

  // Un solo contenido a la vez, por prioridad, dentro de una única ventana
  const resumen = resumir(historial, jugadores);
  let contenido: ReactNode = null;
  if (tarjeta) {
    contenido = (
      <TemaProvider
        modo="dado"
        cambios={{ cabecera: tarjeta.categoria.color, cabeceraTexto: tarjeta.categoria.textoCabecera }}
      >
        <TarjetaContenido
          key={tarjeta.id}
          tarjeta={tarjeta.tarjeta}
          para={jugadores[turno]}
          otro={jugadores[(turno + 1) % jugadores.length]}
          pases={pases[turno]}
          onHecho={(respuesta, acierto) => resolverTarjeta('hecha', respuesta, acierto)}
          onPasar={() => resolverTarjeta('pasada')}
        />
      </TemaProvider>
    );
  } else if (final !== null) {
    contenido = (
      <FinalContenido
        texto={final}
        onContinuar={() => {
          setFinal(null);
          setFin(true);
        }}
      />
    );
  } else if (resumenAbierto) {
    contenido = <ResumenContenido resumen={resumen} onCerrar={() => setResumenAbierto(false)} />;
  } else if (menuAbierto) {
    contenido = (
      <MenuContenido
        onReglas={abrirReglas}
        onResumen={abrirResumen}
        onReiniciar={pedirReinicio}
        onSalir={pedirSalida}
        onCerrar={() => setMenuAbierto(false)}
      />
    );
  } else if (fin) {
    contenido = (
      <FinDadoContenido
        total={total}
        resumen={resumen}
        onOtraVez={reiniciar}
        onResumen={() => setResumenAbierto(true)}
        onSalir={salir}
      />
    );
  }

  const actual = jugadores[turno];

  return (
    <TemaProvider modo="dado">
      <SafeAreaView edges={['bottom']} style={[styles.contenedor, { backgroundColor: tema.fondo }]}>
        <Stack.Screen
          options={{
            title: 'Dado de temas',
            headerStyle: { backgroundColor: tema.fondo },
            headerTintColor: tema.texto,
            headerTitleStyle: { color: tema.texto },
            headerShadowVisible: false,
          }}
        />

        <View style={styles.barra}>
          <Text style={[styles.ronda, { color: tema.texto }]}>
            Tirada {Math.min(ronda + 1, total)} de {total}
          </Text>
          <Pressable
            onPress={() => setMenuAbierto(true)}
            hitSlop={10}
            style={[styles.menuBoton, { backgroundColor: tema.acento }]}
          >
            <Text style={[styles.menuTexto, { color: tema.acentoTexto }]}>⋯ Menú</Text>
          </Pressable>
        </View>

        <View style={[styles.progreso, { backgroundColor: tema.borde }]}>
          <View
            style={[
              styles.progresoRelleno,
              { width: `${(ronda / total) * 100}%`, backgroundColor: tema.acento },
            ]}
          />
        </View>

        <View style={styles.turno}>
          <View style={[styles.punto, { backgroundColor: actual.color }]} />
          <Text style={[styles.turnoTexto, { color: tema.texto }]}>Turno de {actual.nombre}</Text>
          <Text style={[styles.pases, { color: tema.textoSuave }]}>⏭️ {pases[turno]}</Text>
        </View>

        <View style={styles.escenario}>
          <View
            style={[
              styles.mesa,
              {
                width: mesa,
                height: mesa,
                borderRadius: mesa / 2,
                backgroundColor: tema.fondoTablero,
                borderColor: tema.pista,
              },
            ]}
          >
            {tirada ? (
              <DadoAnimado
                key={tirada.id}
                valor={tirada.valor}
                size={tamDado}
                inclinacion={tirada.inclinacion}
                desde={reposo}
                entrada="centro"
                caras={CARAS_CATEGORIAS}
                onTerminar={terminarTirada}
              />
            ) : (
              <DadoReposo
                valor={reposo.valor}
                inclinacion={reposo.inclinacion}
                size={tamDado}
                caras={CARAS_CATEGORIAS}
              />
            )}
          </View>

          <View style={styles.categoriaFila}>
            {categoriaActual ? (
              <View style={[styles.pildora, { backgroundColor: categoriaActual.color }]}>
                <Text style={[styles.pildoraTexto, { color: categoriaActual.textoCabecera }]}>
                  {categoriaActual.icono} {categoriaActual.nombre}
                </Text>
              </View>
            ) : (
              <Text style={[styles.ayuda, { color: tema.textoSuave }]}>
                {tirada ? 'Rodando…' : 'Tira el dado y descubre el tema'}
              </Text>
            )}
          </View>

          <View style={styles.leyenda}>
            {CATEGORIAS_DADO.map((c, i) => (
              <View
                key={c.categoria}
                style={[
                  styles.leyendaItem,
                  { backgroundColor: c.color },
                  categoriaActual?.categoria === c.categoria && styles.leyendaActiva,
                ]}
              >
                <Text style={styles.leyendaIcono}>{c.icono}</Text>
                <Text style={styles.leyendaNumero}>{i + 1}</Text>
              </View>
            ))}
          </View>
        </View>

        <Pressable
          style={[
            styles.boton,
            { backgroundColor: tema.acento },
            (tirada !== null || contenido !== null) && styles.botonInactivo,
          ]}
          onPress={tirar}
          disabled={tirada !== null || contenido !== null}
        >
          <Text style={[styles.botonTexto, { color: tema.acentoTexto }]}>🎲 Tirar dado</Text>
        </Pressable>

        <Capa visible={contenido !== null}>{contenido}</Capa>
      </SafeAreaView>
    </TemaProvider>
  );
}

const styles = StyleSheet.create({
  contenedor: { flex: 1, alignItems: 'center', paddingTop: 4, paddingBottom: 12 },
  barra: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  ronda: { fontSize: 16, fontWeight: '700' },
  menuBoton: { paddingVertical: 6, paddingHorizontal: 14, borderRadius: 999 },
  menuTexto: { fontSize: 14, fontWeight: '700' },
  progreso: { width: '90%', height: 6, borderRadius: 3, marginTop: 10, overflow: 'hidden' },
  progresoRelleno: { height: 6, borderRadius: 3 },
  turno: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
  punto: { width: 14, height: 14, borderRadius: 7 },
  turnoTexto: { fontSize: 18, fontWeight: '700' },
  pases: { fontSize: 14, fontWeight: '600' },
  escenario: { flex: 1, width: '100%', alignItems: 'center', justifyContent: 'center', gap: 18 },
  mesa: { alignItems: 'center', justifyContent: 'center', borderWidth: 3 },
  categoriaFila: { height: 40, alignItems: 'center', justifyContent: 'center' },
  pildora: { paddingVertical: 8, paddingHorizontal: 20, borderRadius: 999 },
  pildoraTexto: { fontSize: 18, fontWeight: '800' },
  ayuda: { fontSize: 15, fontWeight: '600' },
  leyenda: { flexDirection: 'row', gap: 8 },
  leyendaItem: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0.55,
  },
  leyendaActiva: { opacity: 1, transform: [{ scale: 1.12 }] },
  leyendaIcono: { fontSize: 18 },
  leyendaNumero: { fontSize: 10, fontWeight: '800', color: '#333333' },
  boton: { paddingVertical: 16, paddingHorizontal: 56, borderRadius: 16 },
  botonInactivo: { opacity: 0.45 },
  botonTexto: { fontSize: 20, fontWeight: '800' },
});