import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { DURACIONES } from '../data/dadoTemas';
import { NIVELES } from '../data/decks';
import type { Nivel } from '../data/decks';
import { MODOS } from '../data/modos';
import { COLORES_JUGADOR } from '../theme';

export default function Jugadores() {
  const router = useRouter();
  const { modo } = useLocalSearchParams<{ modo: string }>();
  const modoActual = MODOS.find((m) => m.id === modo) ?? MODOS[0];

  const [nombres, setNombres] = useState(['', '']);
  const [colores, setColores] = useState([0, 1]);
  const [niveles, setNiveles] = useState<Nivel[]>(NIVELES);
  const [tiradas, setTiradas] = useState(15);

  const cambiarNombre = (i: number, texto: string) =>
    setNombres((actual) => actual.map((n, j) => (j === i ? texto : n)));

  const elegirColor = (i: number, color: number) => {
    if (colores[1 - i] === color) return; // ya lo usa la otra persona
    setColores((actual) => actual.map((c, j) => (j === i ? color : c)));
  };

  // Siempre debe quedar al menos un nivel
  const alternarNivel = (nivel: Nivel) =>
    setNiveles((actual) => {
      if (!actual.includes(nivel)) return [...actual, nivel];
      return actual.length > 1 ? actual.filter((n) => n !== nivel) : actual;
    });

  const empezar = () => {
    const jugadores = nombres.map((nombre, i) => ({ nombre, color: colores[i] }));
    if (modoActual.id === 'dado') {
      router.push({
        pathname: '/dado',
        params: { jugadores: JSON.stringify(jugadores), rondas: String(tiradas) },
      });
      return;
    }
    router.push({
      pathname: '/juego',
      params: {
        modo: modoActual.id,
        jugadores: JSON.stringify(jugadores),
        niveles: niveles.join(','),
      },
    });
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.contenido}
        keyboardShouldPersistTaps="handled"
        contentInsetAdjustmentBehavior="automatic"
      >
        <Text style={styles.modo}>
          {modoActual.emoji} {modoActual.id === 'dado' ? '' : 'Modo '}
          {modoActual.nombre}
        </Text>

        {modoActual.id === 'aleatorio' ? (
          <View style={styles.bloque}>
            <Text style={styles.etiqueta}>¿Qué niveles queréis mezclar?</Text>
            <View style={styles.chips}>
              {NIVELES.map((nivel) => {
                const info = MODOS.find((m) => m.id === nivel);
                const activo = niveles.includes(nivel);
                return (
                  <Pressable
                    key={nivel}
                    onPress={() => alternarNivel(nivel)}
                    style={[styles.chip, activo && styles.chipActivo]}
                  >
                    <Text style={[styles.chipTexto, activo && styles.chipTextoActivo]}>
                      {info?.emoji} {info?.nombre}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}

        {modoActual.id === 'dado' ? (
          <View style={styles.bloque}>
            <Text style={styles.etiqueta}>¿Cuánto queréis jugar?</Text>
            <View style={styles.chips}>
              {DURACIONES.map((d) => {
                const activo = tiradas === d.tiradas;
                return (
                  <Pressable
                    key={d.tiradas}
                    onPress={() => setTiradas(d.tiradas)}
                    style={[styles.chip, activo && styles.chipActivo]}
                  >
                    <Text style={[styles.chipTexto, activo && styles.chipTextoActivo]}>
                      {d.nombre} · {d.tiradas} tiradas
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : null}

        {[0, 1].map((i) => (
          <View key={i} style={styles.bloque}>
            <Text style={styles.etiqueta}>Jugador {i + 1}</Text>
            <TextInput
              style={styles.input}
              value={nombres[i]}
              onChangeText={(texto) => cambiarNombre(i, texto)}
              placeholder={`Jugador ${i + 1}`}
              maxLength={14}
              autoCorrect={false}
            />
            <View style={styles.colores}>
              {COLORES_JUGADOR.map((color, indice) => {
                const elegido = colores[i] === indice;
                const ocupado = colores[1 - i] === indice;
                return (
                  <Pressable
                    key={color}
                    onPress={() => elegirColor(i, indice)}
                    style={[
                      styles.color,
                      { backgroundColor: color },
                      elegido && styles.colorElegido,
                      ocupado && styles.colorOcupado,
                    ]}
                  />
                );
              })}
            </View>
          </View>
        ))}

        <Pressable style={styles.boton} onPress={empezar}>
          <Text style={styles.botonTexto}>Empezar a jugar</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  contenido: { padding: 20, gap: 20 },
  modo: { fontSize: 16, fontWeight: '600', textAlign: 'center', color: '#555' },
  bloque: { gap: 10, backgroundColor: '#f4f1ea', borderRadius: 16, padding: 16 },
  etiqueta: { fontSize: 14, fontWeight: '700', color: '#555' },
  input: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 18,
  },
  chips: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  chip: {
    backgroundColor: '#ffffff',
    borderRadius: 999,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  chipActivo: { borderColor: '#2f7d4f', backgroundColor: '#e4f2e8' },
  chipTexto: { fontSize: 15, color: '#888', fontWeight: '600' },
  chipTextoActivo: { color: '#2f7d4f' },
  colores: { flexDirection: 'row', gap: 14 },
  color: { width: 40, height: 40, borderRadius: 20, borderWidth: 3, borderColor: 'transparent' },
  colorElegido: { borderColor: '#222222' },
  colorOcupado: { opacity: 0.2 },
  boton: {
    backgroundColor: '#2f7d4f',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  botonTexto: { color: '#ffffff', fontSize: 18, fontWeight: '700' },
});