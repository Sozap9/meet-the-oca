import { useRouter } from 'expo-router';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MODOS } from '../data/modos';

export default function Modos() {
  const router = useRouter();

  return (
    <ScrollView contentContainerStyle={styles.contenedor} contentInsetAdjustmentBehavior="automatic">
      {MODOS.map((modo) => (
        <Pressable
          key={modo.id}
          style={styles.tarjeta}
          onPress={() => router.push({ pathname: '/jugadores', params: { modo: modo.id } })}
        >
          <Text style={styles.emoji}>{modo.emoji}</Text>
          <View style={styles.textos}>
            <Text style={styles.nombre}>{modo.nombre}</Text>
            <Text style={styles.descripcion}>{modo.descripcion}</Text>
          </View>
        </Pressable>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenedor: { padding: 16, gap: 12 },
  tarjeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    padding: 16,
    borderRadius: 14,
    backgroundColor: '#f4f1ea',
  },
  emoji: { fontSize: 32 },
  textos: { flex: 1 },
  nombre: { fontSize: 18, fontWeight: '700' },
  descripcion: { fontSize: 14, color: '#666' },
});