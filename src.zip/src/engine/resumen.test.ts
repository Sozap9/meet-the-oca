import { prefieres, pregunta, reto } from '../data/tarjetas';
import { crearJuego } from './juego';
import { resumir, textoTarjeta } from './resumen';
import type { Entrada } from './resumen';

const jugadores = crearJuego([
  { nombre: 'Ana', color: '#aa0000' },
  { nombre: 'Luis', color: '#00aa00' },
]).jugadores;

const historial: Entrada[] = [
  { jugador: 0, tarjeta: pregunta('¿Color favorito?'), resultado: 'hecha' },
  { jugador: 1, tarjeta: reto('Cuenta un chiste'), resultado: 'pasada' },
  { jugador: 1, tarjeta: prefieres('Playa', 'Montaña'), resultado: 'hecha' },
];

describe('resumen', () => {
  it('cuenta tarjetas hechas y pasadas por jugador', () => {
    const resumen = resumir(historial, jugadores);
    expect(resumen.porJugador[0]).toMatchObject({ nombre: 'Ana', hechas: 1, pasadas: 0 });
    expect(resumen.porJugador[1]).toMatchObject({ nombre: 'Luis', hechas: 1, pasadas: 1 });
  });

  it('calcula los totales', () => {
    const resumen = resumir(historial, jugadores);
    expect(resumen.totalHechas).toBe(2);
    expect(resumen.totalPasadas).toBe(1);
    expect(resumen.hechas).toHaveLength(2);
  });

  it('describe las tarjetas de elegir con sus dos opciones', () => {
    expect(textoTarjeta(prefieres('Playa', 'Montaña'))).toBe('Playa o Montaña');
  });
});