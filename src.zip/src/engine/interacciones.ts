export type TipoRonda = 'adivinar' | 'semaforo' | 'debate';

export interface OpcionRonda {
  id: string;
  etiqueta: string;
  color?: string;
}

export const OPCIONES_SEMAFORO: OpcionRonda[] = [
  { id: 'verde', etiqueta: 'Verde · me apetece', color: '#4caf6a' },
  { id: 'amarillo', etiqueta: 'Amarillo · quizá', color: '#f2b134' },
  { id: 'rojo', etiqueta: 'Rojo · prefiero que no', color: '#d9534f' },
];

export const OPCIONES_DEBATE: OpcionRonda[] = [
  { id: 'acuerdo', etiqueta: 'De acuerdo' },
  { id: 'depende', etiqueta: 'Depende' },
  { id: 'desacuerdo', etiqueta: 'En desacuerdo' },
];

export interface Resultado {
  mensaje: string;
  acierto?: boolean; // solo en "adivinar"
}

// Qué se cuenta cuando las dos personas han respondido
export function resolverRonda(tipo: TipoRonda, primera: string, segunda: string): Resultado {
  switch (tipo) {
    case 'semaforo':
      if (primera === 'rojo' || segunda === 'rojo') {
        return { mensaje: 'Hay un rojo: se respeta, y pasáis a otra cosa.' };
      }
      if (primera === 'verde' && segunda === 'verde') {
        return { mensaje: '¡Los dos en verde! Hablad de cómo y cuándo.' };
      }
      return { mensaje: 'Hay amarillos: contad qué os hace dudar.' };
    case 'debate':
      return primera === segunda
        ? { mensaje: 'Pensáis parecido. ¿Por qué?' }
        : { mensaje: 'Opináis distinto: debatidlo un minuto.' };
    case 'adivinar':
      return primera === segunda
        ? { mensaje: '¡Acierto! Qué bien os conocéis.', acierto: true }
        : { mensaje: 'No era esa. ¿Os sorprende?', acierto: false };
  }
}