import { PASES_INICIALES, crearPases, darPase, gastarPase } from './pases';

describe('pases', () => {
  it('cada jugador empieza con los pases iniciales', () => {
    expect(crearPases(2)).toEqual([PASES_INICIALES, PASES_INICIALES]);
  });

  it('gastar un pase solo afecta a ese jugador', () => {
    expect(gastarPase([3, 3], 1)).toEqual([3, 2]);
  });

  it('no se pueden gastar pases que no se tienen', () => {
    const sinPases = [0, 3];
    expect(gastarPase(sinPases, 0)).toBe(sinPases);
  });

  it('el comodín da un pase extra', () => {
    expect(darPase([3, 3], 0)).toEqual([4, 3]);
  });
});