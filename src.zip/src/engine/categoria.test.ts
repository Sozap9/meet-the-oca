import { en, pregunta } from '../data/tarjetas';
import { crearBaraja, intensidadSegunRonda } from './mazos';

describe('categoría', () => {
  const mazo = [pregunta('A', en('futuro')(1)), pregunta('B', en('retos')(1))];

  it('roba solo de la categoría pedida', () => {
    expect(crearBaraja(mazo, () => 0).robar(undefined, undefined, 'retos')?.texto).toBe('B');
  });

  it('devuelve null si no hay tarjetas de esa categoría', () => {
    expect(crearBaraja(mazo, () => 0).robar(undefined, undefined, 'intimo')).toBeNull();
  });
});

describe('intensidad por tirada', () => {
  it('sube a lo largo de la partida', () => {
    expect(intensidadSegunRonda(0, 8)).toBe(1);
    expect(intensidadSegunRonda(3, 8)).toBe(2);
    expect(intensidadSegunRonda(6, 8)).toBe(3);
  });
});