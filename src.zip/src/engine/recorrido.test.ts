import { aplicarTirada, crearJuego, retroceder } from './juego';
import type { EstadoJuego } from './juego';
import { rutaDeEventos } from './recorrido';

function partida(posiciones: number[]): EstadoJuego {
  const estado = crearJuego(
    posiciones.map((_, i) => ({ nombre: `J${i + 1}`, color: '#000000' })),
  );
  return {
    ...estado,
    jugadores: estado.jugadores.map((j, i) => ({ ...j, posicion: posiciones[i] })),
  };
}

const posiciones = (pasos: { posicion: number }[]) => pasos.map((p) => p.posicion);

describe('recorrido de la ficha', () => {
  it('camina casilla a casilla desde la salida', () => {
    const nuevo = aplicarTirada(partida([0, 0]), 4);
    const ruta = rutaDeEventos(nuevo.eventos, 0);
    expect(posiciones(ruta)).toEqual([1, 2, 3, 4]);
    expect(ruta.every((p) => p.tipo === 'paso')).toBe(true);
  });

  it('en el rebote llega al 63 y vuelve hacia atrás', () => {
    const nuevo = aplicarTirada(partida([60, 0]), 5); // 65 → rebota a la 61
    expect(posiciones(rutaDeEventos(nuevo.eventos, 0))).toEqual([61, 62, 63, 62, 61]);
  });

  it('el laberinto camina hasta la casilla y luego salta al 30', () => {
    const nuevo = aplicarTirada(partida([38, 0]), 4);
    const ruta = rutaDeEventos(nuevo.eventos, 0);
    expect(posiciones(ruta)).toEqual([39, 40, 41, 42, 30]);
    expect(ruta[ruta.length - 1].tipo).toBe('salto');
  });

  it('la calavera salta a la casilla 1', () => {
    const nuevo = aplicarTirada(partida([55, 0]), 3);
    const ruta = rutaDeEventos(nuevo.eventos, 0);
    expect(posiciones(ruta)).toEqual([56, 57, 58, 1]);
    expect(ruta[ruta.length - 1].tipo).toBe('salto');
  });

  it('retroceder en la apuesta es un salto', () => {
    const nuevo = retroceder(partida([20, 5]), 0, 10);
    expect(rutaDeEventos(nuevo.eventos, 0)).toEqual([{ posicion: 10, tipo: 'salto' }]);
  });

  it('solo cuenta la ficha del jugador pedido', () => {
    const nuevo = aplicarTirada(partida([7, 0]), 3);
    expect(rutaDeEventos(nuevo.eventos, 1)).toEqual([]);
  });
});