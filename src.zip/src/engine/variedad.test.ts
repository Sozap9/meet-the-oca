import { pregunta, reto } from '../data/tarjetas';
import { crearBaraja } from './mazos';

describe('variedad', () => {
  it('evita dos tarjetas seguidas del mismo tipo si hay alternativa', () => {
    const baraja = crearBaraja([pregunta('A'), pregunta('B'), reto('C')], () => 0);
    const primera = baraja.robar();
    const segunda = baraja.robar();
    expect(primera?.tipo).not.toBe(segunda?.tipo);
  });
});