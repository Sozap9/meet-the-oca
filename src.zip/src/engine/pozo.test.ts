import { aplicarTirada, crearJuego, rescatarDelPozo } from './juego';
import type { EstadoJuego } from './juego';

function partida(posiciones: number[]): EstadoJuego {
  const estado = crearJuego(
    posiciones.map((_, i) => ({ nombre: `J${i + 1}`, color: '#000000' })),
  );
  return {
    ...estado,
    jugadores: estado.jugadores.map((j, i) => ({ ...j, posicion: posiciones[i] })),
  };
}

const saltosPorPozo = (estado: EstadoJuego) =>
  estado.eventos.filter((e) => e.tipo === 'saltaTurno' && e.motivo === 'pozo');

describe('pozo con la otra persona por delante', () => {
  it('cada turno que se salta deja un aviso para la pregunta desde arriba', () => {
    let estado = aplicarTirada(partida([28, 33]), 3); // J1 cae en el pozo y J2 va por delante
    expect(estado.eventos.some((e) => e.tipo === 'pozo' && e.resultado === 'condena')).toBe(true);

    // J2 juega y se salta el turno de J1, tres veces
    for (const valor of [1, 1, 2]) {
      estado = aplicarTirada(estado, valor);
      expect(saltosPorPozo(estado)).toHaveLength(1);
    }

    // A la cuarta, J1 ya ha salido del pozo y ya no hay más saltos
    estado = aplicarTirada(estado, 1);
    expect(saltosPorPozo(estado)).toHaveLength(0);
    expect(estado.jugadores[0].enPozo).toBe(false);
    expect(estado.turno).toBe(0);
  });

  it('que la otra persona avance no libera a quien cumple los tres turnos', () => {
    const estado = aplicarTirada(aplicarTirada(partida([28, 33]), 3), 1);
    expect(estado.jugadores[0].enPozo).toBe(true);
    expect(estado.jugadores[0].turnosPozo).toBe(2);
  });

  it('la cuerda saca antes de tiempo', () => {
    const dentro = aplicarTirada(partida([28, 33]), 3);
    const libre = rescatarDelPozo(dentro, 0, 1);
    expect(libre.jugadores[0].enPozo).toBe(false);
    expect(libre.jugadores[0].turnosPozo).toBeNull();

    // La otra persona juega y el turno vuelve ya a quien estaba dentro
    expect(aplicarTirada(libre, 1).turno).toBe(0);
  });
});

describe('pozo hasta que le pasen', () => {
  it('cada turno que se salta también deja el aviso', () => {
    const estado = aplicarTirada(aplicarTirada(partida([28, 10]), 3), 2);
    expect(saltosPorPozo(estado)).toHaveLength(1);
    expect(estado.jugadores[0].enPozo).toBe(true);
  });
});