import { CASILLAS_APUESTA, perdedorDeDados } from './dados';
import {
  aplicarTirada,
  crearJuego,
  liberarPenalizacion,
  rescatarDelPozo,
  retroceder,
} from './juego';
import type { EstadoJuego } from './juego';

function partida(posiciones: number[]): EstadoJuego {
  const estado = crearJuego(
    posiciones.map((_, i) => ({ nombre: `J${i + 1}`, color: '#000000' })),
  );
  return {
    ...estado,
    jugadores: estado.jugadores.map((j, i) => ({ ...j, posicion: posiciones[i] })),
  };
}

describe('pagar la penalización', () => {
  it('pagar la posada evita perder el turno', () => {
    const cae = aplicarTirada(partida([16, 0]), 3); // cae en la 19
    expect(cae.jugadores[0].turnosPerdidos).toBe(1);

    const paga = liberarPenalizacion(cae, 0, 'posada');
    expect(paga.jugadores[0].turnosPerdidos).toBe(0);
    expect(paga.eventos.some((e) => e.tipo === 'pagaPenalizacion')).toBe(true);

    // La otra persona juega y el turno vuelve directamente a quien pagó
    expect(aplicarTirada(paga, 2).turno).toBe(0);
  });

  it('pagar la fianza saca de la cárcel', () => {
    const cae = aplicarTirada(partida([49, 0]), 3); // cae en la 52
    expect(cae.jugadores[0].turnosPerdidos).toBe(2);

    const paga = liberarPenalizacion(cae, 0, 'carcel');
    expect(paga.jugadores[0].turnosPerdidos).toBe(0);
    expect(aplicarTirada(paga, 1).turno).toBe(0);
  });

  it('no modifica el estado original', () => {
    const cae = aplicarTirada(partida([16, 0]), 3);
    const copia = JSON.parse(JSON.stringify(cae));
    liberarPenalizacion(cae, 0, 'posada');
    expect(cae).toEqual(copia);
  });
});

describe('retroceder', () => {
  it('retrocede las casillas de la apuesta', () => {
    const nuevo = retroceder(partida([20, 5]), 0, CASILLAS_APUESTA);
    expect(nuevo.jugadores[0].posicion).toBe(10);
    expect(nuevo.eventos.some((e) => e.tipo === 'retrocede')).toBe(true);
  });

  it('no baja de la salida', () => {
    expect(retroceder(partida([4, 0]), 0, CASILLAS_APUESTA).jugadores[0].posicion).toBe(0);
  });
});

describe('pozo: cuerda y preguntas desde arriba', () => {
  it('la cuerda libera a quien estaba atrapado sin cambiar el turno', () => {
    const atrapado = aplicarTirada(partida([28, 10]), 3); // cae en la 31
    expect(atrapado.jugadores[0].enPozo).toBe(true);

    const libre = rescatarDelPozo(atrapado, 0, 1);
    expect(libre.jugadores[0].enPozo).toBe(false);
    expect(libre.turno).toBe(1);
  });

  it('cada turno saltado por el pozo deja un aviso para la pregunta', () => {
    const atrapado = aplicarTirada(partida([28, 10]), 3);
    const siguiente = aplicarTirada(atrapado, 2); // la otra persona juega
    const saltos = siguiente.eventos.filter(
      (e) => e.tipo === 'saltaTurno' && e.motivo === 'pozo',
    );
    expect(saltos).toHaveLength(1);
    expect(siguiente.turno).toBe(1);
  });
});

describe('casillas de verdad o reto y de dados', () => {
  it('caer en los dados avisa del duelo o la apuesta', () => {
    const nuevo = aplicarTirada(partida([20, 0]), 6); // cae en la 26
    expect(nuevo.eventos.some((e) => e.tipo === 'dados')).toBe(true);
    expect(nuevo.eventos.some((e) => e.tipo === 'verdadReto')).toBe(false);
  });

  it('caer en el puente avisa de verdad o reto', () => {
    const nuevo = aplicarTirada(partida([3, 0]), 3); // cae en la 6
    expect(nuevo.eventos.some((e) => e.tipo === 'verdadReto')).toBe(true);
    expect(nuevo.eventos.some((e) => e.tipo === 'dados')).toBe(false);
  });

  it('pierde quien saca menos y los empates se repiten', () => {
    expect(perdedorDeDados([2, 5])).toBe(0);
    expect(perdedorDeDados([6, 1])).toBe(1);
    expect(perdedorDeDados([3, 3])).toBeNull();
  });
});