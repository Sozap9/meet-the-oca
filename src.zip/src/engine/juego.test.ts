import { aplicarTirada, crearJuego } from './juego';
import type { EstadoJuego } from './juego';

// Partida con jugadores en las posiciones indicadas (el primero tiene el turno)
function partida(posiciones: number[]): EstadoJuego {
  const estado = crearJuego(
    posiciones.map((_, i) => ({ nombre: `J${i + 1}`, color: '#000000' })),
  );
  return {
    ...estado,
    jugadores: estado.jugadores.map((j, i) => ({ ...j, posicion: posiciones[i] })),
  };
}

// Aplica varias tiradas seguidas
function tirarVarias(estado: EstadoJuego, valores: number[]): EstadoJuego {
  return valores.reduce((actual, valor) => aplicarTirada(actual, valor), estado);
}

// Partida en la que el primer jugador ya está atrapado en el pozo y le toca al segundo
function conPrimeroEnPozo(posiciones: number[]): EstadoJuego {
  const base = partida(posiciones);
  return {
    ...base,
    turno: 1,
    jugadores: base.jugadores.map((j, i) => (i === 0 ? { ...j, enPozo: true } : j)),
  };
}

describe('avance básico', () => {
  it('avanza y pasa el turno', () => {
    const nuevo = aplicarTirada(partida([0, 0]), 3);
    expect(nuevo.jugadores[0].posicion).toBe(3);
    expect(nuevo.turno).toBe(1);
    expect(nuevo.ganador).toBeNull();
  });

  it('no modifica el estado original', () => {
    const original = partida([2, 0]);
    const copia = JSON.parse(JSON.stringify(original));
    aplicarTirada(original, 3);
    expect(original).toEqual(copia);
  });
});

describe('oca y verdad o reto', () => {
  it('oca: se queda en su casilla y vuelve a tirar', () => {
    const nuevo = aplicarTirada(partida([2, 0]), 3); // cae en la 5
    expect(nuevo.jugadores[0].posicion).toBe(5);
    expect(nuevo.turno).toBe(0);
  });

  it('la oca del 59 ya no lleva al jardín', () => {
    const nuevo = aplicarTirada(partida([56, 0]), 3);
    expect(nuevo.jugadores[0].posicion).toBe(59);
    expect(nuevo.ganador).toBeNull();
    expect(nuevo.turno).toBe(0);
  });

  it('verdad o reto (6): no salta y pasa el turno', () => {
    const nuevo = aplicarTirada(partida([3, 0]), 3);
    expect(nuevo.jugadores[0].posicion).toBe(6);
    expect(nuevo.turno).toBe(1);
  });

  it('verdad o reto (12): tampoco salta', () => {
    const nuevo = aplicarTirada(partida([8, 0]), 4);
    expect(nuevo.jugadores[0].posicion).toBe(12);
    expect(nuevo.turno).toBe(1);
  });

  it('las casillas de los dados (26) tampoco saltan', () => {
    const nuevo = aplicarTirada(partida([20, 0]), 6);
    expect(nuevo.jugadores[0].posicion).toBe(26);
    expect(nuevo.turno).toBe(1);
  });
});

describe('retrocesos', () => {
  it('laberinto: retrocede a la 30 y pasa el turno', () => {
    const nuevo = aplicarTirada(partida([38, 0]), 4);
    expect(nuevo.jugadores[0].posicion).toBe(30);
    expect(nuevo.turno).toBe(1);
  });

  it('calavera: vuelve a la 1 y pasa el turno', () => {
    const nuevo = aplicarTirada(partida([55, 0]), 3);
    expect(nuevo.jugadores[0].posicion).toBe(1);
    expect(nuevo.turno).toBe(1);
  });
});

describe('turnos perdidos', () => {
  it('posada: pierde un turno', () => {
    let estado = aplicarTirada(partida([16, 0]), 3); // cae en la 19
    expect(estado.jugadores[0].turnosPerdidos).toBe(1);
    expect(estado.turno).toBe(1);

    estado = aplicarTirada(estado, 2); // la otra persona juega y el turno se salta
    expect(estado.turno).toBe(1);
    expect(estado.jugadores[0].turnosPerdidos).toBe(0);

    estado = aplicarTirada(estado, 1); // ahora sí vuelve
    expect(estado.turno).toBe(0);
  });

  it('cárcel: pierde dos turnos', () => {
    let estado = aplicarTirada(partida([49, 0]), 3); // cae en la 52
    expect(estado.jugadores[0].turnosPerdidos).toBe(2);

    estado = aplicarTirada(estado, 1);
    expect(estado.turno).toBe(1);
    estado = aplicarTirada(estado, 1);
    expect(estado.turno).toBe(1);
    estado = aplicarTirada(estado, 1);
    expect(estado.turno).toBe(0);
  });
});

describe('pozo', () => {
  it('queda atrapado hasta que le pasen si la otra persona va por detrás', () => {
    const nuevo = aplicarTirada(partida([28, 10]), 3); // cae en la 31
    expect(nuevo.jugadores[0].enPozo).toBe(true);
    expect(nuevo.jugadores[0].turnosPozo).toBeNull();
    expect(nuevo.jugadores[0].turnosPerdidos).toBe(0);
    expect(nuevo.turno).toBe(1);
  });

  it('se queda dentro tres turnos si la otra persona ya va por delante', () => {
    let estado = aplicarTirada(partida([28, 33]), 3);
    expect(estado.jugadores[0].enPozo).toBe(true);
    expect(estado.jugadores[0].turnosPozo).toBe(3);
    expect(estado.turno).toBe(1);

    // La otra persona juega cuatro veces seguidas y luego vuelve el turno
    const turnos: number[] = [];
    for (const valor of [1, 1, 2, 1]) {
      estado = aplicarTirada(estado, valor);
      turnos.push(estado.turno);
    }
    expect(turnos).toEqual([1, 1, 1, 0]);
    expect(estado.jugadores[0].enPozo).toBe(false);
  });

  it('se libera cuando la otra persona lo pasa', () => {
    const estado = conPrimeroEnPozo([31, 28]);

    const aunDentro = tirarVarias(estado, [2]); // llega a la 30: aún no lo pasa
    expect(aunDentro.jugadores[0].enPozo).toBe(true);
    expect(aunDentro.turno).toBe(1);

    const libre = tirarVarias(aunDentro, [3]); // llega a la 33: lo pasa
    expect(libre.jugadores[0].enPozo).toBe(false);
    expect(libre.turno).toBe(0);
  });

  it('no se libera si la otra persona no llega a pasarlo', () => {
    const nuevo = aplicarTirada(conPrimeroEnPozo([31, 20]), 2);
    expect(nuevo.jugadores[0].enPozo).toBe(true);
    expect(nuevo.turno).toBe(1);
  });

  it('cae justo en el pozo: rescata a quien estaba atrapado', () => {
    const nuevo = aplicarTirada(conPrimeroEnPozo([31, 28]), 3);
    expect(nuevo.jugadores[0].enPozo).toBe(false);
    expect(nuevo.jugadores[1].enPozo).toBe(false);
    expect(nuevo.jugadores[1].posicion).toBe(31);
    expect(nuevo.turno).toBe(0);
  });

  it('pasar cuenta aunque luego retroceda por la calavera', () => {
    const nuevo = aplicarTirada(conPrimeroEnPozo([31, 55]), 3); // cae en la 58 y vuelve a la 1
    expect(nuevo.jugadores[1].posicion).toBe(1);
    expect(nuevo.jugadores[0].enPozo).toBe(false);
    expect(nuevo.turno).toBe(0);
  });
});

describe('jardín', () => {
  it('llegar exacto al 63 gana', () => {
    const nuevo = aplicarTirada(partida([60, 0]), 3);
    expect(nuevo.jugadores[0].posicion).toBe(63);
    expect(nuevo.ganador).toBe(0);
  });

  it('si se pasa del 63, rebota', () => {
    const nuevo = aplicarTirada(partida([60, 0]), 5); // 65 → rebota a la 61
    expect(nuevo.jugadores[0].posicion).toBe(61);
    expect(nuevo.ganador).toBeNull();
    expect(nuevo.turno).toBe(1);
  });

  it('el rebote aplica la casilla donde cae (calavera)', () => {
    const nuevo = aplicarTirada(partida([62, 0]), 6); // 68 → rebota a la 58 → calavera
    expect(nuevo.jugadores[0].posicion).toBe(1);
  });

  it('una vez hay ganador no se juega más', () => {
    const ganada = aplicarTirada(partida([60, 0]), 3);
    expect(aplicarTirada(ganada, 4)).toBe(ganada);
  });
});