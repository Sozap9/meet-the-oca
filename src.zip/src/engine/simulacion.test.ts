import { aplicarTirada, crearJuego } from './juego';

// Generador pseudoaleatorio con semilla, para que la prueba sea repetible
function generador(semilla: number) {
  let s = semilla;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

function jugarPartida(azar: () => number) {
  let estado = crearJuego([
    { nombre: 'A', color: '#000000' },
    { nombre: 'B', color: '#000000' },
  ]);
  let tiradas = 0;
  while (estado.ganador === null && tiradas < 5000) {
    estado = aplicarTirada(estado, Math.floor(azar() * 6) + 1);
    tiradas++;
  }
  return { estado, tiradas };
}

describe('simulación de partidas', () => {
  it('todas las partidas terminan, sin quedarse atascadas', () => {
    const azar = generador(12345);
    for (let i = 0; i < 2000; i++) {
      const { estado, tiradas } = jugarPartida(azar);
      expect(estado.ganador).not.toBeNull();
      expect(tiradas).toBeLessThan(5000);
    }
  });

  it('una partida dura un tiempo razonable', () => {
    const azar = generador(98765);
    const partidas = 1000;
    let total = 0;
    for (let i = 0; i < partidas; i++) total += jugarPartida(azar).tiradas;
    const media = total / partidas;

    // Tiradas totales entre las dos personas (cada una suele tirar la mitad)
    console.log(`Duración media: ${media.toFixed(1)} tiradas en total`);
    expect(media).toBeGreaterThan(25);
    expect(media).toBeLessThan(120);
  });
});