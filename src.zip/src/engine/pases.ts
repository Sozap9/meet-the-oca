export const PASES_INICIALES = 3;

export function crearPases(jugadores: number): number[] {
  return Array.from({ length: jugadores }, () => PASES_INICIALES);
}

export function gastarPase(pases: number[], jugador: number): number[] {
  if (pases[jugador] <= 0) return pases;
  return pases.map((n, i) => (i === jugador ? n - 1 : n));
}

export function darPase(pases: number[], jugador: number): number[] {
  return pases.map((n, i) => (i === jugador ? n + 1 : n));
}