import { pregunta, reto } from '../data/tarjetas';
import { claseDeCasilla, crearBaraja } from './mazos';

const sinAzar = () => 0;

describe('baraja', () => {
  it('no repite tarjetas hasta agotar el mazo', () => {
    const baraja = crearBaraja([pregunta('A'), pregunta('B'), pregunta('C')], sinAzar);
    const robadas = [baraja.robar(), baraja.robar(), baraja.robar()];
    expect(new Set(robadas).size).toBe(3);
  });

  it('se vuelve a barajar cuando se agota', () => {
    const baraja = crearBaraja([pregunta('A')], sinAzar);
    baraja.robar();
    expect(baraja.robar()?.texto).toBe('A');
  });

  it('filtra por tipo', () => {
    const baraja = crearBaraja([pregunta('A'), reto('B'), pregunta('C')], sinAzar);
    expect(baraja.robar(['reto'])?.texto).toBe('B');
  });

  it('devuelve null si no hay tarjetas del tipo pedido', () => {
    const baraja = crearBaraja([pregunta('A')], sinAzar);
    expect(baraja.robar(['reto'])).toBeNull();
  });
});

describe('claseDeCasilla', () => {
  it('asigna a cada casilla lo que ocurre al caer en ella', () => {
    expect(claseDeCasilla('normal')).toBe('cualquiera');
    expect(claseDeCasilla('oca')).toBe('ligera');
    expect(claseDeCasilla('puente')).toBe('verdadOReto');
    expect(claseDeCasilla('dados')).toBe('dados');
    expect(claseDeCasilla('posada')).toBe('posada');
    expect(claseDeCasilla('carcel')).toBe('carcel');
  });

  it('las demás casillas no tienen nada especial', () => {
    expect(claseDeCasilla('pozo')).toBeNull();
    expect(claseDeCasilla('laberinto')).toBeNull();
    expect(claseDeCasilla('calavera')).toBeNull();
    expect(claseDeCasilla('jardin')).toBeNull();
  });
});