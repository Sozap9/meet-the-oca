import {
  CARAS,
  aCuaternion,
  aplicar,
  deCuaternion,
  orientacionFinal,
  rotacionAleatoria,
  rotar,
  slerp,
} from './dado3d';
import type { Mat, Vec } from './dado3d';

function casiIguales(a: number[][], b: number[][]) {
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) expect(a[i][j]).toBeCloseTo(b[i][j], 5);
  }
}

describe('dado 3D', () => {
  it('la cara pedida queda mirando al jugador', () => {
    for (const cara of CARAS) {
      const normal = aplicar(orientacionFinal(cara.valor, 0), cara.n);
      expect(normal[0]).toBeCloseTo(0, 5);
      expect(normal[1]).toBeCloseTo(0, 5);
      expect(normal[2]).toBeCloseTo(1, 5);
    }
  });

  it('las caras opuestas suman 7', () => {
    for (const cara of CARAS) {
      const opuesta = CARAS.find((c) => c.valor === 7 - cara.valor)!;
      for (let i = 0; i < 3; i++) expect(cara.n[i] + opuesta.n[i]).toBe(0);
    }
  });

  it('una rotación no cambia las longitudes', () => {
    const v: Vec = [1, 2, 3];
    const r = aplicar(rotar([0, 0, 1], 1.1), v);
    expect(Math.hypot(...r)).toBeCloseTo(Math.hypot(...v), 5);
  });

  it('una vuelta completa vuelve a la misma orientación', () => {
    casiIguales(rotar([0.6, 0.0, 0.8], Math.PI * 2), [
      [1, 0, 0],
      [0, 1, 0],
      [0, 0, 1],
    ]);
  });

  it('pasar a cuaternión y volver conserva la orientación', () => {
    for (let i = 0; i < 20; i++) {
      const m = rotacionAleatoria();
      casiIguales(deCuaternion(aCuaternion(m)), m);
    }
  });

  it('slerp empieza y acaba en las orientaciones dadas', () => {
    const a: Mat = rotacionAleatoria();
    const b: Mat = rotacionAleatoria();
    const qa = aCuaternion(a);
    const qb = aCuaternion(b);
    casiIguales(deCuaternion(slerp(qa, qb, 0)), a);
    casiIguales(deCuaternion(slerp(qa, qb, 1)), b);
  });
});