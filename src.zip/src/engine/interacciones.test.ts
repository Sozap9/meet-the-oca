import { resolverRonda } from './interacciones';

describe('resolverRonda', () => {
  it('semáforo: un rojo se respeta', () => {
    expect(resolverRonda('semaforo', 'verde', 'rojo').mensaje).toContain('rojo');
    expect(resolverRonda('semaforo', 'rojo', 'amarillo').mensaje).toContain('rojo');
  });

  it('semáforo: los dos en verde', () => {
    expect(resolverRonda('semaforo', 'verde', 'verde').mensaje).toContain('verde');
  });

  it('semáforo: con amarillos se habla', () => {
    expect(resolverRonda('semaforo', 'verde', 'amarillo').mensaje).toContain('amarillo');
  });

  it('debate: coincidir o discrepar', () => {
    expect(resolverRonda('debate', 'acuerdo', 'acuerdo').mensaje).toContain('parecido');
    expect(resolverRonda('debate', 'acuerdo', 'desacuerdo').mensaje).toContain('distinto');
  });

  it('adivinar: acierto y fallo', () => {
    expect(resolverRonda('adivinar', 'Dulce', 'Dulce').acierto).toBe(true);
    expect(resolverRonda('adivinar', 'Dulce', 'Salado').acierto).toBe(false);
  });
});