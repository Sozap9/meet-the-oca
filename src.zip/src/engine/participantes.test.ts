import { leerParticipantes } from './participantes';

const COLORES = ['#aa0000', '#00aa00', '#0000aa', '#aaaa00'];

describe('leerParticipantes', () => {
  it('usa valores por defecto si no hay datos', () => {
    expect(leerParticipantes(undefined, COLORES)).toEqual([
      { nombre: 'Jugador 1', color: '#aa0000' },
      { nombre: 'Jugador 2', color: '#00aa00' },
    ]);
  });

  it('lee nombres y colores', () => {
    const texto = JSON.stringify([
      { nombre: 'Ana', color: 2 },
      { nombre: 'Luis', color: 3 },
    ]);
    expect(leerParticipantes(texto, COLORES)).toEqual([
      { nombre: 'Ana', color: '#0000aa' },
      { nombre: 'Luis', color: '#aaaa00' },
    ]);
  });

  it('rellena nombres vacíos y recorta los demasiado largos', () => {
    const texto = JSON.stringify([
      { nombre: '   ', color: 0 },
      { nombre: 'X'.repeat(30), color: 1 },
    ]);
    const resultado = leerParticipantes(texto, COLORES);
    expect(resultado[0].nombre).toBe('Jugador 1');
    expect(resultado[1].nombre).toBe('X'.repeat(14));
  });

  it('ignora datos corruptos', () => {
    expect(leerParticipantes('esto no es json', COLORES)[0].nombre).toBe('Jugador 1');
  });
});