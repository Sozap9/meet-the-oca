import { en, pregunta } from '../data/tarjetas';
import { crearJuego } from './juego';
import { crearBaraja, intensidadSegunProgreso } from './mazos';

const g = en('gustos');

const jugadoresEn = (posiciones: number[]) =>
  crearJuego(posiciones.map((_, i) => ({ nombre: `J${i}`, color: '#000000' }))).jugadores.map(
    (j, i) => ({ ...j, posicion: posiciones[i] }),
  );

describe('intensidad', () => {
  it('prefiere la intensidad pedida', () => {
    const mazo = [pregunta('A', g(1)), pregunta('B', g(3))];
    expect(crearBaraja(mazo, () => 0).robar(undefined, 3)?.texto).toBe('B');
    expect(crearBaraja(mazo, () => 0).robar(undefined, 1)?.texto).toBe('A');
  });

  it('si no hay de esa intensidad, usa la más cercana', () => {
    const mazo = [pregunta('A', g(1)), pregunta('C', g(2))];
    expect(crearBaraja(mazo, () => 0).robar(undefined, 3)?.texto).toBe('C');
  });

  it('la intensidad sube con el avance de la partida', () => {
    expect(intensidadSegunProgreso(jugadoresEn([0, 10]))).toBe(1);
    expect(intensidadSegunProgreso(jugadoresEn([30, 5]))).toBe(2);
    expect(intensidadSegunProgreso(jugadoresEn([50, 0]))).toBe(3);
    expect(intensidadSegunProgreso(jugadoresEn([63, 0]))).toBe(3);
  });
});