import { aplicarTirada, crearJuego } from './juego';
import type { EstadoJuego } from './juego';
import { describirPase, resumirTurno } from './mensajes';

function partida(posiciones: number[], enPozo: number[] = [], turno = 0): EstadoJuego {
  const estado = crearJuego(
    posiciones.map((_, i) => ({ nombre: `J${i + 1}`, color: '#000000' })),
  );
  return {
    ...estado,
    turno,
    jugadores: estado.jugadores.map((j, i) => ({
      ...j,
      posicion: posiciones[i],
      enPozo: enPozo.includes(i),
    })),
  };
}

describe('resumen de turno para el historial', () => {
  it('cuenta lo que sacó y dónde cae', () => {
    const nuevo = aplicarTirada(partida([0, 0]), 4);
    expect(resumirTurno(nuevo, 0, 4, nuevo.eventos)).toBe('J1: 🎲 4 → casilla 4');
  });

  it('anota la oca y que vuelve a tirar', () => {
    const nuevo = aplicarTirada(partida([2, 0]), 3);
    const texto = resumirTurno(nuevo, 0, 3, nuevo.eventos);
    expect(texto).toContain('casilla 5');
    expect(texto).toContain('oca');
    expect(texto).toContain('vuelve a tirar');
  });

  it('anota el rebote', () => {
    const nuevo = aplicarTirada(partida([60, 0]), 5);
    expect(resumirTurno(nuevo, 0, 5, nuevo.eventos)).toContain('rebota a la 61');
  });

  it('anota el laberinto', () => {
    const nuevo = aplicarTirada(partida([38, 0]), 4);
    expect(resumirTurno(nuevo, 0, 4, nuevo.eventos)).toContain('vuelve a la 30');
  });

  it('anota que el otro sigue en el pozo', () => {
    // J1 está en el pozo y tira J2 (turno 1)
    const nuevo = aplicarTirada(partida([28, 10], [0], 1), 2);
    const texto = resumirTurno(nuevo, 1, 2, nuevo.eventos);
    expect(texto).toContain('J2: 🎲 2 → casilla 12');
    expect(texto).toContain('J1 sigue en el pozo');
  });
});

describe('pases gastados en el historial', () => {
  const estado = partida([0, 0]);

  it('dice cuántos le quedan y cuántos ha gastado', () => {
    expect(describirPase(estado, 0, 2, 1)).toBe('⏭️ J1 gasta un pase · le quedan 2 (gastados: 1)');
  });

  it('distingue el último pase y cuando ya no quedan', () => {
    expect(describirPase(estado, 1, 1, 2)).toContain('le queda 1');
    expect(describirPase(estado, 1, 0, 3)).toContain('ya no le quedan');
  });
});