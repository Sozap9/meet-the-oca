import { adivinaOpciones } from '../data/tarjetas';
import { crearJuego } from './juego';
import { resumir } from './resumen';
import type { Entrada } from './resumen';

const jugadores = crearJuego([
  { nombre: 'Ana', color: '#aa0000' },
  { nombre: 'Luis', color: '#00aa00' },
]).jugadores;

describe('sintonía', () => {
  it('cuenta aciertos y total de las tarjetas de adivinar', () => {
    const tarjeta = adivinaOpciones('¿Cuál?', ['A', 'B']);
    const historial: Entrada[] = [
      { jugador: 0, tarjeta, resultado: 'hecha', acierto: true },
      { jugador: 1, tarjeta, resultado: 'hecha', acierto: false },
      { jugador: 0, tarjeta, resultado: 'hecha' },
    ];
    expect(resumir(historial, jugadores).sintonia).toEqual({ aciertos: 1, total: 2 });
  });

  it('sin tarjetas de adivinar no hay sintonía', () => {
    expect(resumir([], jugadores).sintonia).toBeNull();
  });
});