import { TipoCasilla } from './data/board';

export const COLORES_CASILLA: Record<TipoCasilla, string> = {
  normal: '#f4f1ea',
  oca: '#bfe3b4',
  puente: '#b8d8f0',
  dados: '#f6d99a',
  posada: '#e3d0f0',
  pozo: '#c9c9c9',
  laberinto: '#f0c4b8',
  carcel: '#d6d0c4',
  calavera: '#f2a6a6',
  jardin: '#f7e27a',
};

export const ICONOS_CASILLA: Record<TipoCasilla, string> = {
  normal: '',
  oca: '🪿',
  puente: '🌉',
  dados: '🎲',
  posada: '🛏️',
  pozo: '🕳️',
  laberinto: '🌀',
  carcel: '⛓️',
  calavera: '💀',
  jardin: '🏁',
};

export const COLOR_NORMAL_ALTERNO = '#e9e3d4';
export const COLOR_PISTA = '#2f6b5f';
export const REDONDEO_CASILLA = 0.3; // proporción del lado; 0.5 = círculo
export const COLOR_FONDO_TABLERO = '#efe9dc';
export const COLORES_JUGADOR = ['#e4572e', '#2e86e4', '#f2b134', '#7b4bd6'];