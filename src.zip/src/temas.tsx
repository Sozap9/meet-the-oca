import { createContext, useContext } from 'react';
import type { ReactNode } from 'react';
import type { Modo } from './data/modos';

export interface Tema {
  fondo: string; // fondo de la pantalla de partida
  fondoTablero: string; // lo que se ve entre los anillos de la pista
  pista: string; // la cinta que une las casillas
  casilla: string; // casilla normal
  casillaAlterna: string; // casilla normal par
  numero: string; // número de las casillas normales
  centro: string; // hueco de la imagen central
  centroBorde: string;
  centroTexto: string;
  acento: string; // botones principales
  acentoTexto: string;
  texto: string; // textos de la pantalla
  textoSuave: string;
  tarjeta: string; // fondo de las tarjetas y ventanas
  cabecera: string; // banda superior de la tarjeta
  cabeceraTexto: string;
  opcionActiva: string; // fondo de la opción elegida
  borde: string; // bordes suaves
}

export const TEMAS: Record<Modo, Tema> = {
  basico: {
    fondo: '#eef7fb',
    fondoTablero: '#e3f1d8',
    pista: '#79bd88',
    casilla: '#fbf8ee',
    casillaAlterna: '#f0ebd6',
    numero: '#7a8a6c',
    centro: '#cfe8f5',
    centroBorde: '#8ec9e8',
    centroTexto: '#4c7f99',
    acento: '#4f9d69',
    acentoTexto: '#ffffff',
    texto: '#24382c',
    textoSuave: '#5f7566',
    tarjeta: '#fbf8ee',
    cabecera: '#79bd88',
    cabeceraTexto: '#18331f',
    opcionActiva: '#e4f2e8',
    borde: '#cfd8c9',
  },
  personal: {
    fondo: '#ebe8f6',
    fondoTablero: '#d6d0ec',
    pista: '#3b3f78',
    casilla: '#f7f3fc',
    casillaAlterna: '#e9e2f5',
    numero: '#6c6598',
    centro: '#7b6fb5',
    centroBorde: '#5b4a8a',
    centroTexto: '#ffffff',
    acento: '#5b4a8a',
    acentoTexto: '#ffffff',
    texto: '#2a2a55',
    textoSuave: '#6a6794',
    tarjeta: '#f7f3fc',
    cabecera: '#5b4a8a',
    cabeceraTexto: '#ffffff',
    opcionActiva: '#e9e2f5',
    borde: '#d6d0ec',
  },
  caliente: {
    fondo: '#fbe9ea',
    fondoTablero: '#f3cdd3',
    pista: '#7a1f3d',
    casilla: '#fff4f1',
    casillaAlterna: '#f9e1dc',
    numero: '#a05a66',
    centro: '#f2b6c0',
    centroBorde: '#c0405e',
    centroTexto: '#7a1f3d',
    acento: '#c0405e',
    acentoTexto: '#ffffff',
    texto: '#4a1226',
    textoSuave: '#8a4a5e',
    tarjeta: '#fff4f1',
    cabecera: '#7a1f3d',
    cabeceraTexto: '#ffffff',
    opcionActiva: '#f9e1dc',
    borde: '#f1c9cf',
  },
  aleatorio: {
    fondo: '#f7f1e1',
    fondoTablero: '#efe6cf',
    pista: '#6a5aa8',
    casilla: '#fffaf0',
    casillaAlterna: '#f3ead2',
    numero: '#8a8372',
    centro: '#fff1c9',
    centroBorde: '#f6c453',
    centroTexto: '#8a6a12',
    acento: '#e0546a',
    acentoTexto: '#ffffff',
    texto: '#33302a',
    textoSuave: '#7a7466',
    tarjeta: '#fffaf0',
    cabecera: '#6a5aa8',
    cabeceraTexto: '#ffffff',
    opcionActiva: '#fde8ec',
    borde: '#e6dcc0',
  },
  dado: {
    fondo: '#e8f1f0',
    fondoTablero: '#cfe3e0',
    pista: '#2f6b5f',
    casilla: '#fbfbf7',
    casillaAlterna: '#eef3f1',
    numero: '#6b8a85',
    centro: '#cfe3e0',
    centroBorde: '#2f6b5f',
    centroTexto: '#2f6b5f',
    acento: '#2f6b5f',
    acentoTexto: '#ffffff',
    texto: '#1d3b36',
    textoSuave: '#5b7872',
    tarjeta: '#fbfbf7',
    cabecera: '#2f6b5f',
    cabeceraTexto: '#ffffff',
    opcionActiva: '#dcebe8',
    borde: '#cfe0dc',
  },
};

const TemaContext = createContext<Tema>(TEMAS.basico);

// "cambios" permite retocar algún color de un tema (por ejemplo, la cabecera de una tarjeta)
export function TemaProvider({
  modo,
  cambios,
  children,
}: {
  modo: Modo;
  cambios?: Partial<Tema>;
  children: ReactNode;
}) {
  return (
    <TemaContext.Provider value={{ ...TEMAS[modo], ...cambios }}>{children}</TemaContext.Provider>
  );
}

export function useTema(): Tema {
  return useContext(TemaContext);
}