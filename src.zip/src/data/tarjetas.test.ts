import { completa, interaccionDe, prefieres, pregunta, yoNunca } from './tarjetas';

describe('interaccionDe', () => {
  it('"¿Qué prefieres?" se resuelve eligiendo', () => {
    expect(interaccionDe(prefieres('Playa', 'Montaña'))).toEqual({
      tipo: 'elegir',
      opciones: ['Playa', 'Montaña'],
    });
  });

  it('"Yo nunca" ofrece sí o no', () => {
    expect(interaccionDe(yoNunca('Yo nunca he…'))).toEqual({
      tipo: 'elegir',
      opciones: ['Yo sí', 'Yo no'],
    });
  });

  it('"Completa la frase" se escribe', () => {
    expect(interaccionDe(completa('Mi plan es…')).tipo).toBe('escribir');
  });

  it('una pregunta normal se responde hablando', () => {
    expect(interaccionDe(pregunta('¿Y tú?')).tipo).toBe('ninguna');
  });

  it('una interacción indicada manda sobre la del tipo', () => {
    const tarjeta = { ...pregunta('¿Y tú?'), interaccion: { tipo: 'escribir' as const } };
    expect(interaccionDe(tarjeta).tipo).toBe('escribir');
  });
});