export type TipoTarjeta =
  | 'pregunta'
  | 'prefieres'
  | 'adivina'
  | 'completa'
  | 'dosVerdades'
  | 'yoNunca'
  | 'reto'
  | 'recuerdo'
  | 'plan'
  | 'comodin'
  | 'semaforo'
  | 'debate';

// 1 = ligera, 2 = media, 3 = profunda
export type Intensidad = 1 | 2 | 3;

export type Categoria =
  // Básico
  | 'gustos'
  | 'humor'
  | 'rutinas'
  | 'viajes'
  | 'prefieres'
  // Personal
  | 'recuerdos'
  | 'valores'
  | 'futuro'
  | 'miedos'
  | 'delicados'
  // Caliente
  | 'atraccion'
  | 'coqueteo'
  | 'citas'
  | 'deseos'
  | 'cercania'
  | 'libre'
  // Dado de temas (futuro se comparte con Personal)
  | 'ligeras'
  | 'reflexiones'
  | 'confesiones'
  | 'intimo'
  | 'retos';

export const INFO_CATEGORIA: Record<Categoria, { nombre: string; icono: string }> = {
  gustos: { nombre: 'Gustos', icono: '🎧' },
  humor: { nombre: 'Humor', icono: '😂' },
  rutinas: { nombre: 'Rutinas', icono: '☀️' },
  viajes: { nombre: 'Viajes y planes', icono: '🧭' },
  prefieres: { nombre: '¿Qué prefieres?', icono: '🤔' },
  recuerdos: { nombre: 'Recuerdos', icono: '📸' },
  valores: { nombre: 'Valores', icono: '💎' },
  futuro: { nombre: 'Futuro', icono: '🔭' },
  miedos: { nombre: 'Miedos y confianza', icono: '🌧️' },
  delicados: { nombre: 'Temas delicados', icono: '🕊️' },
  atraccion: { nombre: 'Atracción', icono: '✨' },
  coqueteo: { nombre: 'Coqueteo', icono: '😉' },
  citas: { nombre: 'Citas y sorpresas', icono: '🍷' },
  deseos: { nombre: 'Deseos', icono: '🚦' },
  cercania: { nombre: 'Retos de cercanía', icono: '🤝' },
  libre: { nombre: 'Libre', icono: '🎁' },
  ligeras: { nombre: 'Ligeras', icono: '🎈' },
  reflexiones: { nombre: 'Reflexiones', icono: '💭' },
  confesiones: { nombre: 'Confesiones', icono: '🤫' },
  intimo: { nombre: 'Íntimo', icono: '💞' },
  retos: { nombre: 'Retos', icono: '🎢' },
};

// Etiqueta de una tarjeta: su categoría y su intensidad
export interface Meta {
  categoria: Categoria;
  intensidad: Intensidad;
}

// en('gustos')(2) → { categoria: 'gustos', intensidad: 2 }
export const en =
  (categoria: Categoria) =>
  (intensidad: Intensidad): Meta => ({ categoria, intensidad });

// Cómo se responde una tarjeta dentro de la app
export type Interaccion =
  | { tipo: 'ninguna' } // se responde hablando
  | { tipo: 'elegir'; opciones: string[] }
  | { tipo: 'escribir' }
  | { tipo: 'escala'; min: number; max: number; etiquetas?: [string, string] }
  | { tipo: 'adivinar'; opciones: string[] } // una persona responde en secreto y la otra adivina
  | { tipo: 'semaforo' } // verde, amarillo o rojo, cada uno sin ver al otro
  | { tipo: 'debate' } // de acuerdo o no, cada uno sin ver al otro
  | { tipo: 'temporizador'; segundos: number };

export interface Tarjeta {
  tipo: TipoTarjeta;
  texto: string;
  opciones?: [string, string]; // solo en "¿Qué prefieres?"
  interaccion?: Interaccion; // si no se indica, depende del tipo
  categoria?: Categoria;
  intensidad?: Intensidad;
}

export const INFO_TIPO: Record<
  TipoTarjeta,
  { etiqueta: string; icono: string; indicacion: string; color: string }
> = {
  pregunta: { etiqueta: 'Pregunta', icono: '💬', indicacion: 'Responde con sinceridad', color: '#dcebf5' },
  prefieres: { etiqueta: '¿Qué prefieres?', icono: '🤔', indicacion: 'Elige una y cuenta por qué', color: '#f6d99a' },
  adivina: { etiqueta: 'Adivina sobre mí', icono: '🔮', indicacion: 'Piensa tu respuesta; tu pareja intenta adivinarla', color: '#e3d0f0' },
  completa: { etiqueta: 'Completa la frase', icono: '✍️', indicacion: 'Termínala en voz alta o escríbela', color: '#bfe3b4' },
  dosVerdades: { etiqueta: 'Dos verdades y una mentira', icono: '🎭', indicacion: 'Tu pareja debe descubrir la mentira', color: '#f0c4b8' },
  yoNunca: { etiqueta: 'Yo nunca', icono: '🙈', indicacion: 'Si lo has hecho, cuéntalo', color: '#f2d3e0' },
  reto: { etiqueta: 'Reto', icono: '🎯', indicacion: 'Cúmplelo o pásalo', color: '#f2a6a6' },
  recuerdo: { etiqueta: 'Recuerdo compartido', icono: '📸', indicacion: 'Cuéntalo con detalle', color: '#b8d8f0' },
  plan: { etiqueta: 'Plan de futuro', icono: '🗺️', indicacion: 'Imagínalo en voz alta', color: '#f7e27a' },
  comodin: { etiqueta: 'Comodín', icono: '🃏', indicacion: '', color: '#d6d0c4' },
  semaforo: { etiqueta: 'Semáforo', icono: '🚦', indicacion: '', color: '#f2d3a0' },
  debate: { etiqueta: 'Debate', icono: '⚖️', indicacion: '', color: '#d6e4f5' },
};

// La interacción de una tarjeta: la indicada o, si no, la habitual de su tipo
export function interaccionDe(tarjeta: Tarjeta): Interaccion {
  if (tarjeta.interaccion) return tarjeta.interaccion;
  switch (tarjeta.tipo) {
    case 'prefieres':
      return { tipo: 'elegir', opciones: tarjeta.opciones ?? [] };
    case 'yoNunca':
      return { tipo: 'elegir', opciones: ['Yo sí', 'Yo no'] };
    case 'completa':
      return { tipo: 'escribir' };
    default:
      return { tipo: 'ninguna' };
  }
}

// Funciones para escribir los mazos de forma corta; el último parámetro es la etiqueta
const crear =
  (tipo: TipoTarjeta) =>
  (texto: string, meta?: Meta): Tarjeta => ({ tipo, texto, ...meta });

export const pregunta = crear('pregunta');
export const adivina = crear('adivina');
export const completa = crear('completa');
export const yoNunca = crear('yoNunca');
export const reto = crear('reto');
export const recuerdo = crear('recuerdo');
export const plan = crear('plan');

export const prefieres = (a: string, b: string, meta?: Meta): Tarjeta => ({
  tipo: 'prefieres',
  texto: '¿Qué prefieres?',
  opciones: [a, b],
  ...meta,
});

export const dosVerdades = (
  texto = 'Cuenta tres cosas sobre ti: dos verdaderas y una falsa.',
  meta?: Meta,
): Tarjeta => ({ tipo: 'dosVerdades', texto, ...meta });

export const comodin = (
  texto = 'Comodín: elige tú una pregunta para tu pareja.',
  meta?: Meta,
): Tarjeta => ({ tipo: 'comodin', texto, ...meta });

// Tarjetas interactivas
export const escala = (
  texto: string,
  etiquetas?: [string, string],
  meta?: Meta,
): Tarjeta => ({
  tipo: 'pregunta',
  texto,
  interaccion: { tipo: 'escala', min: 1, max: 10, etiquetas },
  ...meta,
});

export const adivinaOpciones = (texto: string, opciones: string[], meta?: Meta): Tarjeta => ({
  tipo: 'adivina',
  texto,
  interaccion: { tipo: 'adivinar', opciones },
  ...meta,
});

export const adivinaNumero = (texto: string, meta?: Meta): Tarjeta =>
  adivinaOpciones(
    texto,
    Array.from({ length: 10 }, (_, i) => String(i + 1)),
    meta,
  );

export const semaforo = (texto: string, meta?: Meta): Tarjeta => ({
  tipo: 'semaforo',
  texto,
  interaccion: { tipo: 'semaforo' },
  ...meta,
});

export const debate = (texto: string, meta?: Meta): Tarjeta => ({
  tipo: 'debate',
  texto,
  interaccion: { tipo: 'debate' },
  ...meta,
});

export const retoConTiempo = (texto: string, segundos = 30, meta?: Meta): Tarjeta => ({
  tipo: 'reto',
  texto,
  interaccion: { tipo: 'temporizador', segundos },
  ...meta,
});