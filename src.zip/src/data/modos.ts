export type Modo = 'basico' | 'personal' | 'caliente' | 'aleatorio' | 'dado';

export const MODOS: {
  id: Modo;
  nombre: string;
  descripcion: string;
  emoji: string;
}[] = [
  { id: 'basico', nombre: 'Básico', descripcion: 'Gustos y curiosidades para empezar', emoji: '🌱' },
  { id: 'personal', nombre: 'Personal', descripcion: 'Recuerdos, sueños y cómo eres', emoji: '💬' },
  { id: 'caliente', nombre: 'Caliente', descripcion: 'Más cercanía, coqueteo y retos', emoji: '🔥' },
  { id: 'aleatorio', nombre: 'Aleatorio', descripcion: 'Una mezcla de los tres modos', emoji: '🎲' },
  { id: 'dado', nombre: 'Dado de temas', descripcion: 'Un dado elige el tema y salta la pregunta', emoji: '🧩' },
];