import { TOTAL_CASILLAS } from './board';
import { AREA_CENTRAL, COLUMNAS, FILAS, POSICIONES } from './espiral';

describe('recorrido en espiral', () => {
  it('tiene una posición para la salida y otra para cada casilla', () => {
    expect(POSICIONES).toHaveLength(TOTAL_CASILLAS + 1);
  });

  it('la salida está abajo a la izquierda', () => {
    expect(POSICIONES[0]).toEqual({ fila: FILAS - 1, columna: 0 });
  });

  it('todas las posiciones están dentro del tablero y no se repiten', () => {
    const vistas = new Set<string>();
    for (const { fila, columna } of POSICIONES) {
      expect(fila).toBeGreaterThanOrEqual(0);
      expect(fila).toBeLessThan(FILAS);
      expect(columna).toBeGreaterThanOrEqual(0);
      expect(columna).toBeLessThan(COLUMNAS);
      vistas.add(`${fila},${columna}`);
    }
    expect(vistas.size).toBe(POSICIONES.length);
  });

  it('cada casilla es contigua a la anterior', () => {
    for (let i = 1; i < POSICIONES.length; i++) {
      const distancia =
        Math.abs(POSICIONES[i].fila - POSICIONES[i - 1].fila) +
        Math.abs(POSICIONES[i].columna - POSICIONES[i - 1].columna);
      expect(distancia).toBe(1);
    }
  });

  it('el hueco de la imagen central queda libre', () => {
    for (const { fila, columna } of POSICIONES) {
      const dentro =
        fila >= AREA_CENTRAL.fila &&
        fila < AREA_CENTRAL.fila + AREA_CENTRAL.filas &&
        columna >= AREA_CENTRAL.columna &&
        columna < AREA_CENTRAL.columna + AREA_CENTRAL.columnas;
      expect(dentro).toBe(false);
    }
  });
});