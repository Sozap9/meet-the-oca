import type { Categoria } from './tarjetas';

export interface CategoriaDado {
  nombre: string;
  icono: string;
  color: string; // color de la cara del dado y de la cabecera de la tarjeta
  textoCabecera: string; // color del texto sobre ese color
  categoria: Categoria;
}

// La cara 1 del dado es la primera de la lista, la 2 la segunda, etc.
export const CATEGORIAS_DADO: CategoriaDado[] = [
  { nombre: 'Ligeras', icono: '🎈', color: '#8fcf9a', textoCabecera: '#18331f', categoria: 'ligeras' },
  { nombre: 'Futuro', icono: '🔭', color: '#8ec9e8', textoCabecera: '#12384f', categoria: 'futuro' },
  { nombre: 'Reflexiones', icono: '💭', color: '#7b6fb5', textoCabecera: '#ffffff', categoria: 'reflexiones' },
  { nombre: 'Confesiones', icono: '🤫', color: '#e0867a', textoCabecera: '#3d140e', categoria: 'confesiones' },
  { nombre: 'Íntimo', icono: '💞', color: '#c0405e', textoCabecera: '#ffffff', categoria: 'intimo' },
  { nombre: 'Retos', icono: '🎢', color: '#f6c453', textoCabecera: '#4a3504', categoria: 'retos' },
];

export const DURACIONES = [
  { nombre: 'Rápido', tiradas: 8 },
  { nombre: 'Normal', tiradas: 15 },
  { nombre: 'Largo', tiradas: 20 },
];

// Lee el número de tiradas que llega por la ruta; por defecto, la normal
export function leerRondas(texto: string | undefined): number {
  const n = Number(texto);
  return DURACIONES.some((d) => d.tiradas === n) ? n : 15;
}