import type { Tarjeta } from '../tarjetas';
import { BASICO } from './basico';
import { CALIENTE } from './caliente';
import { PERSONAL } from './personal';

const MAZOS: { nombre: string; mazo: Tarjeta[]; categorias: string[] }[] = [
  {
    nombre: 'básico',
    mazo: BASICO,
    categorias: ['gustos', 'humor', 'rutinas', 'viajes', 'prefieres'],
  },
  {
    nombre: 'personal',
    mazo: PERSONAL,
    categorias: ['recuerdos', 'valores', 'futuro', 'miedos', 'delicados'],
  },
  {
    nombre: 'caliente',
    mazo: CALIENTE,
    categorias: ['atraccion', 'coqueteo', 'citas', 'deseos', 'cercania', 'libre'],
  },
];

describe.each(MAZOS)('mazo $nombre', ({ mazo, categorias }) => {
  const tarjetas = mazo.filter((t) => t.tipo !== 'comodin');

  it('toda tarjeta, salvo el comodín, lleva categoría e intensidad', () => {
    for (const t of tarjetas) {
      expect(t.categoria).toBeDefined();
      expect(t.intensidad).toBeDefined();
    }
  });

  it('solo usa las categorías del modo', () => {
    for (const t of tarjetas) expect(categorias).toContain(t.categoria);
  });

  it('cada categoría tiene al menos tres tarjetas', () => {
    for (const categoria of categorias) {
      expect(tarjetas.filter((t) => t.categoria === categoria).length).toBeGreaterThanOrEqual(3);
    }
  });

  it('hay tarjetas de las tres intensidades', () => {
    for (const intensidad of [1, 2, 3]) {
      expect(tarjetas.some((t) => t.intensidad === intensidad)).toBe(true);
    }
  });

  it('hay retos suficientes para cuando se elige "reto"', () => {
    expect(mazo.filter((t) => t.tipo === 'reto').length).toBeGreaterThanOrEqual(3);
  });
});

describe('semáforo', () => {
  it('solo aparece en el modo caliente', () => {
    expect(CALIENTE.some((t) => t.tipo === 'semaforo')).toBe(true);
    expect(BASICO.some((t) => t.tipo === 'semaforo')).toBe(false);
    expect(PERSONAL.some((t) => t.tipo === 'semaforo')).toBe(false);
  });
});