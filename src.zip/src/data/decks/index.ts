import type { Modo } from '../modos';
import type { Tarjeta } from '../tarjetas';
import { BASICO } from './basico';
import { CALIENTE } from './caliente';
import { DADO } from './dado';
import { PERSONAL } from './personal';

// Los tres niveles de intensidad (el modo aleatorio mezcla los que se elijan)
export type Nivel = Exclude<Modo, 'aleatorio' | 'dado'>;
export const NIVELES: Nivel[] = ['basico', 'personal', 'caliente'];

const MAZOS: Record<Nivel, Tarjeta[]> = {
  basico: BASICO,
  personal: PERSONAL,
  caliente: CALIENTE,
};

export function tarjetasDeModo(modo: Modo, niveles: Nivel[] = NIVELES): Tarjeta[] {
  if (modo === 'dado') return DADO;
  if (modo === 'aleatorio') {
    const elegidos = niveles.length > 0 ? niveles : NIVELES;
    return elegidos.flatMap((nivel) => MAZOS[nivel]);
  }
  return MAZOS[modo];
}

// Lee los niveles que llegan por la ruta ("basico,personal"); si no hay, todos
export function leerNiveles(texto: string | undefined): Nivel[] {
  if (!texto) return NIVELES;
  const lista = texto
    .split(',')
    .filter((n): n is Nivel => (NIVELES as string[]).includes(n));
  return lista.length > 0 ? lista : NIVELES;
}