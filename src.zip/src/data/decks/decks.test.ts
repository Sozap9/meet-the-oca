import { BASICO } from './basico';
import { CALIENTE } from './caliente';
import { PERSONAL } from './personal';
import { NIVELES, leerNiveles, tarjetasDeModo } from './index';

describe('mazos por modo', () => {
  it('cada modo usa su mazo', () => {
    expect(tarjetasDeModo('basico')).toBe(BASICO);
    expect(tarjetasDeModo('personal')).toBe(PERSONAL);
    expect(tarjetasDeModo('caliente')).toBe(CALIENTE);
  });

  it('aleatorio mezcla solo los niveles elegidos', () => {
    expect(tarjetasDeModo('aleatorio', ['basico', 'caliente'])).toHaveLength(
      BASICO.length + CALIENTE.length,
    );
  });

  it('aleatorio sin niveles usa todos', () => {
    expect(tarjetasDeModo('aleatorio', [])).toHaveLength(
      BASICO.length + PERSONAL.length + CALIENTE.length,
    );
  });

  it('lee los niveles de la ruta', () => {
    expect(leerNiveles(undefined)).toEqual(NIVELES);
    expect(leerNiveles('personal,caliente')).toEqual(['personal', 'caliente']);
    expect(leerNiveles('otra-cosa')).toEqual(NIVELES);
  });
});