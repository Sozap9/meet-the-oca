import { CATEGORIAS_DADO, DURACIONES, leerRondas } from '../dadoTemas';
import { INFO_CATEGORIA } from '../tarjetas';
import { DADO } from './dado';

describe('mazo del dado', () => {
  it('el dado tiene seis caras con colores distintos', () => {
    expect(CATEGORIAS_DADO).toHaveLength(6);
    expect(new Set(CATEGORIAS_DADO.map((c) => c.color)).size).toBe(6);
  });

  it('todas las categorías existen en el catálogo', () => {
    for (const c of CATEGORIAS_DADO) expect(INFO_CATEGORIA[c.categoria]).toBeDefined();
  });

  it('cada cara tiene al menos ocho tarjetas, de las tres intensidades', () => {
    for (const c of CATEGORIAS_DADO) {
      const tarjetas = DADO.filter((t) => t.categoria === c.categoria);
      expect(tarjetas.length).toBeGreaterThanOrEqual(8);
      for (const intensidad of [1, 2, 3]) {
        expect(tarjetas.some((t) => t.intensidad === intensidad)).toBe(true);
      }
    }
  });

  it('lee la duración elegida y usa la normal si no es válida', () => {
    expect(DURACIONES.map((d) => d.tiradas)).toEqual([8, 15, 20]);
    expect(leerRondas('8')).toBe(8);
    expect(leerRondas('20')).toBe(20);
    expect(leerRondas(undefined)).toBe(15);
    expect(leerRondas('99')).toBe(15);
  });
});