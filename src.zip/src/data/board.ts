export type TipoCasilla =
  | 'normal'
  | 'oca'
  | 'puente'
  | 'dados'
  | 'posada'
  | 'pozo'
  | 'laberinto'
  | 'carcel'
  | 'calavera'
  | 'jardin';

export interface Casilla {
  numero: number;
  tipo: TipoCasilla;
  destino?: number; // retroceso fijo: laberinto y calavera
}

export const TOTAL_CASILLAS = 63;

const OCAS = [5, 9, 14, 18, 23, 27, 32, 36, 41, 45, 50, 54, 59];

// "puente" y "dados" son las casillas de Verdad o reto
const ESPECIALES: Record<number, TipoCasilla> = {
  6: 'puente',
  12: 'puente',
  19: 'posada',
  26: 'dados',
  31: 'pozo',
  42: 'laberinto',
  52: 'carcel',
  53: 'dados',
  58: 'calavera',
  63: 'jardin',
};

const DESTINOS: Record<number, number> = {
  42: 30,
  58: 1,
};

export const TABLERO: Casilla[] = Array.from(
  { length: TOTAL_CASILLAS },
  (_, i) => {
    const numero = i + 1;
    const tipo: TipoCasilla = OCAS.includes(numero)
      ? 'oca'
      : (ESPECIALES[numero] ?? 'normal');
    return { numero, tipo, destino: DESTINOS[numero] };
  },
);