import { useRouter } from 'expo-router';

// Vuelve a la portada; si no hay pantallas anteriores (por ejemplo, tras recargar en web), la abre directamente
export function useVolverAlInicio() {
  const router = useRouter();
  return () => {
    if (router.canDismiss()) router.dismissAll();
    else router.replace('/');
  };
}